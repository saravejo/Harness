"""Actual local regression tests for controller mechanics, not OS isolation."""
import importlib.util
import json
import os
import py_compile
import shutil
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / "controller" / "runner.py"
spec = importlib.util.spec_from_file_location("harness_runner", MODULE)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        base = Path(self.temp.name)
        self.project, self.state = base / "project", base / "trusted"
        self.artifacts = self.project / "results/candidates/c1/artifacts"
        self.artifacts.mkdir(parents=True)
        (self.project / "raw/sources").mkdir(parents=True)
        (self.project / "tasks").mkdir()
        (self.project / "qa").mkdir()
        (self.project / "qa/playbook.md").write_text("Review grounding and completeness against the task and sources.\n")
        self.source = self.project / "raw/sources/example.txt"
        self.source.write_text("A widget supports 20 users.\nIts color is blue.\n")
        self.manifest = {"sources": [{"id": "S1", "path": "sources/example.txt",
                                      "sha256": runner.digest(self.source.read_bytes())}]}
        self.task = {"schema_version": 2, "task_id": "t1", "profile": "text-v2",
                     "modules": ["sources"], "limits": {"max_evaluations": 3},
                     "goal": "Summarize the widget evidence.",
                     "required_files": [{"path": "report.md", "headings": ["# Report"],
                                         "require_citations": True}],
                     "review_criteria": ["grounding", "completeness"]}
        self.save(self.project / "raw/manifest.json", self.manifest)
        self.save(self.project / "tasks/t1.json", self.task)
        self.original = "# Report\nThe widget supports 20 users. [[S1:L1-L1]]\n"
        (self.artifacts / "report.md").write_text(self.original)

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def save(path, data):
        path.write_text(json.dumps(data))

    def call(self, command, **kwargs):
        return runner.execute(command, self.project, self.state, **kwargs)

    def evaluate(self):
        self.call("register", task="t1")
        return self.call("evaluate", task="t1", candidate="c1", run="r1")

    def review_file(self, receipt, status="pass"):
        document = {"run_id": receipt["run_id"],
                    "candidate_sha256": receipt["candidate_sha256"],
                    "contract_sha256": receipt["contract_sha256"],
                    "reviewer": "test-fixture-reviewer",
                    "criteria": [{"id": cid, "status": status,
                                  "evidence": "Fixture review: report line 2 / source S1 line 1."}
                                 for cid in self.task["review_criteria"]]}
        path = Path(self.temp.name) / "review.json"
        self.save(path, document)
        return path

    def accept(self):
        receipt = self.evaluate()
        self.assertEqual(receipt["status"], "pass")
        self.call("review", run="r1", file=self.review_file(receipt))
        return receipt

    def test_01_accept_and_release_exact_snapshot(self):
        receipt = self.accept()
        released = self.call("promote", run="r1", release="release1")
        self.assertEqual(released["candidate_sha256"], receipt["candidate_sha256"])
        self.assertEqual((self.state / "releases/release1/artifacts/report.md").read_text(), self.original)

    def test_02_changed_working_copy_does_not_change_release(self):
        self.accept()
        (self.artifacts / "report.md").write_text("Changed after the pass")
        self.call("promote", run="r1", release="release1")
        self.assertEqual((self.state / "releases/release1/artifacts/report.md").read_text(), self.original)

    def test_03_snapshot_tamper_blocks_promotion(self):
        self.accept()
        (self.state / "runs/r1/snapshot/report.md").write_text("tampered")
        with self.assertRaisesRegex(runner.HarnessError, "snapshot changed"):
            self.call("promote", run="r1", release="release1")

    def test_04_missing_review_blocks_promotion(self):
        self.evaluate()
        with self.assertRaises(FileNotFoundError):
            self.call("promote", run="r1", release="release1")
        self.assertFalse((self.state / "releases/release1").exists())

    def test_05_fail_and_unknown_reviews_block_promotion(self):
        receipt = self.evaluate()
        for status in ("fail", "unknown"):
            with self.subTest(status=status):
                result = self.call("review", run="r1", file=self.review_file(receipt, status))
                self.assertEqual(result["status"], "review_rejected")
                with self.assertRaisesRegex(runner.HarnessError, "review did not pass"):
                    self.call("promote", run="r1", release="release1")
                (self.state / "runs/r1/review.json").unlink()  # Test reset; not a controller operation.

    def test_06_missing_review_criterion_is_error(self):
        receipt = self.evaluate()
        path = self.review_file(receipt)
        document = json.loads(path.read_text()); document["criteria"].pop()
        self.save(path, document)
        with self.assertRaisesRegex(runner.HarnessError, "missing, extra or duplicate"):
            self.call("review", run="r1", file=path)

    def test_07_review_for_different_candidate_is_error(self):
        receipt = self.evaluate()
        path = self.review_file(receipt)
        document = json.loads(path.read_text()); document["candidate_sha256"] = "0" * 64
        self.save(path, document)
        with self.assertRaisesRegex(runner.HarnessError, "candidate_sha256 mismatch"):
            self.call("review", run="r1", file=path)

    def test_08_changed_task_blocks_promotion(self):
        self.accept()
        self.task["goal"] = "A changed requirement"
        self.save(self.project / "tasks/t1.json", self.task)
        with self.assertRaisesRegex(runner.HarnessError, "task changed"):
            self.call("promote", run="r1", release="release1")

    def test_09_changed_source_blocks_promotion(self):
        self.accept()
        self.source.write_text("The new source says something else.")
        with self.assertRaisesRegex(runner.HarnessError, "source digest mismatch"):
            self.call("promote", run="r1", release="release1")

    def test_10_changed_evaluator_blocks_promotion(self):
        self.accept()
        with patch.object(runner, "evaluator_digest", return_value="f" * 64):
            with self.assertRaisesRegex(runner.HarnessError, "evaluator changed"):
                self.call("promote", run="r1", release="release1")

    def test_11_missing_file_and_out_of_bounds_locator_fail(self):
        (self.artifacts / "report.md").unlink()
        receipt = self.evaluate()
        self.assertEqual(receipt["status"], "fail")
        (self.artifacts / "report.md").write_text("# Report\nBad reference [[S1:L1-L99]]\n")
        second = self.call("evaluate", task="t1", candidate="c1", run="r2")
        self.assertEqual(second["status"], "fail")
        self.assertIn("invalid source locator", str(second["checks"]))

    def test_12_empty_checks_unknown_profile_and_bool_version_rejected(self):
        for changes in ({"required_files": []}, {"profile": "code"}, {"schema_version": True}):
            with self.subTest(changes=changes):
                config = dict(self.task); config.update(changes)
                self.save(self.project / "tasks/t1.json", config)
                with self.assertRaises(runner.HarnessError):
                    self.call("register", task="t1")

    def test_13_symlink_candidate_rejected_and_error_recorded(self):
        (self.artifacts / "report.md").unlink()
        (self.artifacts / "report.md").symlink_to(self.source)
        result = self.evaluate()
        self.assertEqual(result["status"], "error")
        self.assertIn("symlink forbidden", result["error"])
        self.assertTrue((self.state / "runs/r1/receipt.json").exists())

    def test_14_traversal_is_rejected(self):
        self.task["required_files"][0]["path"] = "../report.md"
        self.save(self.project / "tasks/t1.json", self.task)
        with self.assertRaisesRegex(runner.HarnessError, "unsafe relative"):
            self.call("register", task="t1")

    def test_15_run_and_release_collisions_never_overwrite(self):
        self.accept()
        with self.assertRaisesRegex(runner.HarnessError, "run ID already exists"):
            self.call("evaluate", task="t1", candidate="c1", run="r1")
        self.call("promote", run="r1", release="release1")
        with self.assertRaisesRegex(runner.HarnessError, "already exists"):
            self.call("promote", run="r1", release="release1")

    def test_16_state_inside_project_is_rejected(self):
        with self.assertRaisesRegex(runner.HarnessError, "disjoint"):
            runner.execute("register", self.project, self.project / "state", task="t1")

    def test_17_duplicate_sources_and_unlisted_files_rejected(self):
        self.manifest["sources"].append(dict(self.manifest["sources"][0]))
        self.save(self.project / "raw/manifest.json", self.manifest)
        with self.assertRaisesRegex(runner.HarnessError, "duplicate source"):
            self.call("register", task="t1")
        self.manifest["sources"].pop()
        self.save(self.project / "raw/manifest.json", self.manifest)
        (self.project / "raw/sources/extra.txt").write_text("not registered")
        with self.assertRaisesRegex(runner.HarnessError, "unlisted"):
            self.call("register", task="t1")

    def test_18_structural_pass_does_not_prove_semantics(self):
        (self.artifacts / "report.md").write_text("# Report\nThe widget supports 999 users. [[S1:L1-L1]]\n")
        receipt = self.evaluate()
        self.assertEqual(receipt["status"], "pass")  # Intentionally demonstrates the limitation.
        self.call("review", run="r1", file=self.review_file(receipt, "fail"))
        with self.assertRaisesRegex(runner.HarnessError, "review did not pass"):
            self.call("promote", run="r1", release="release1")

    def test_19_new_extra_artifact_fails_scope_check(self):
        (self.artifacts / "unrequested.txt").write_text("Not in the contract")
        result = self.evaluate()
        self.assertEqual(result["status"], "fail")
        self.assertEqual(result["checks"][0]["id"], "artifact-set")

    def test_20_changed_manifest_blocks_promotion_even_with_same_source(self):
        self.accept()
        path = self.project / "raw/manifest.json"
        path.write_text(path.read_text() + "\n")
        with self.assertRaisesRegex(runner.HarnessError, "manifest changed"):
            self.call("promote", run="r1", release="release1")

    def test_21_symlink_directory_and_duplicate_json_key_rejected(self):
        (self.artifacts / "alias").symlink_to(self.project / "raw", target_is_directory=True)
        result = self.evaluate()
        self.assertEqual(result["status"], "error")
        (self.project / "tasks/t1.json").write_text('{"schema_version":1,"schema_version":1}')
        with self.assertRaisesRegex(runner.HarnessError, "duplicate JSON key"):
            self.call("register", task="t1")

    def test_22_ancestor_symlink_swap_cannot_redirect_read(self):
        candidate = Path(self.temp.name) / "candidate"
        outside = Path(self.temp.name) / "outside"
        candidate.mkdir(); outside.mkdir()
        (candidate / "report.md").write_text("candidate bytes")
        (outside / "report.md").write_text("outside sentinel")
        original_open = os.open
        swapped = False
        def race(path, flags, *args, **kwargs):
            nonlocal swapped
            if path == "candidate" and not swapped:
                candidate.rename(candidate.with_name("saved-candidate"))
                candidate.symlink_to(outside, target_is_directory=True)
                swapped = True
            return original_open(path, flags, *args, **kwargs)
        with patch.object(runner.os, "open", side_effect=race):
            with self.assertRaises(OSError):
                runner.read_bytes(candidate / "report.md")
        self.assertTrue(swapped)

    def test_23_rubric_change_blocks_promotion(self):
        self.accept()
        (self.project / "qa/playbook.md").write_text("Weakened review criteria")
        with self.assertRaisesRegex(runner.HarnessError, "rubric changed"):
            self.call("promote", run="r1", release="release1")

    def test_24_directory_read_error_is_not_silent(self):
        with patch.object(runner.os, "scandir", side_effect=PermissionError("fixture denied")):
            with self.assertRaises(PermissionError):
                runner.files_in(self.artifacts)

    def test_25_source_free_task_needs_no_raw_or_wiki(self):
        self.task["modules"] = []
        self.task["required_files"][0]["require_citations"] = False
        self.save(self.project / "tasks/t1.json", self.task)
        shutil.rmtree(self.project / "raw")
        (self.artifacts / "report.md").write_text("# Report\nA source-free formatting task.\n")
        receipt = self.accept()
        self.assertIsNone(receipt["manifest_sha256"])
        self.assertIsNone(receipt["knowledge_sha256"])
        self.call("promote", run="r1", release="release1")
        self.assertEqual(runner.execute("verify-release", state=self.state, release="release1")["status"], "verified")

    def test_26_optional_module_constraints_are_explicit(self):
        invalid = [({"modules": []}, "citations require"),
                   ({"modules": ["knowledge"]}, "knowledge requires"),
                   ({"limits": {"max_evaluations": True}}, "positive integer"),
                   ({"limits": {"max_evaluations": 0}}, "positive integer")]
        for changes, message in invalid:
            with self.subTest(changes=changes):
                self.save(self.project / "tasks/t1.json", {**self.task, **changes})
                with self.assertRaisesRegex(runner.HarnessError, message):
                    self.call("register", task="t1")

    def test_27_controller_inside_project_is_rejected(self):
        directory = self.project / "controller"; directory.mkdir()
        with patch.object(runner, "CONTROLLER_ROOT", directory):
            with self.assertRaisesRegex(runner.HarnessError, "outside the project"):
                self.call("register", task="t1")

    def test_28_cap_counts_failed_and_error_evaluations(self):
        self.task["limits"]["max_evaluations"] = 2
        self.save(self.project / "tasks/t1.json", self.task)
        self.call("register", task="t1")
        (self.artifacts / "report.md").write_text("missing heading")
        self.assertEqual(self.call("evaluate", task="t1", candidate="c1", run="r1")["status"], "fail")
        (self.artifacts / "report.md").unlink()
        (self.artifacts / "report.md").symlink_to(self.source)
        self.assertEqual(self.call("evaluate", task="t1", candidate="c1", run="r2")["status"], "error")
        with self.assertRaisesRegex(runner.HarnessError, "limit reached"):
            self.call("evaluate", task="t1", candidate="c1", run="r3")

    def test_29_preflight_and_reused_ids_do_not_consume_admissions(self):
        self.call("register", task="t1")
        with self.assertRaises(runner.HarnessError):
            self.call("evaluate", task="t1", candidate="missing", run="r-missing")
        self.assertEqual(runner.admission_count(self.state, "t1"), 0)
        self.call("evaluate", task="t1", candidate="c1", run="r1")
        with self.assertRaisesRegex(runner.HarnessError, "already exists"):
            self.call("evaluate", task="t1", candidate="c1", run="r1")
        self.assertEqual(runner.admission_count(self.state, "t1"), 1)

    def test_30_interrupted_admitted_evaluation_counts(self):
        self.task["limits"]["max_evaluations"] = 1
        self.save(self.project / "tasks/t1.json", self.task)
        self.call("register", task="t1")
        directory = self.state / "runs/interrupted"; directory.mkdir()
        self.save(directory / "admission.json", {"run_id": "interrupted", "task_id": "t1",
                  "candidate_id": "c1", "ordinal": 1, "created_utc": "fixture"})
        with self.assertRaisesRegex(runner.HarnessError, "limit reached"):
            self.call("evaluate", task="t1", candidate="c1", run="r1")

    def test_31_concurrent_admissions_cannot_overdraw_cap(self):
        self.call("register", task="t1")
        def worker(number):
            for _ in range(200):
                try:
                    return self.call("evaluate", task="t1", candidate="c1", run=f"r{number}")["status"]
                except runner.HarnessError as exc:
                    if "busy" in str(exc):
                        time.sleep(0.001)
                    else:
                        return str(exc)
            return "retry exhausted"
        with ThreadPoolExecutor(max_workers=5) as pool:
            outcomes = list(pool.map(worker, range(5)))
        self.assertEqual(outcomes.count("pass"), 3, outcomes)
        self.assertEqual(sum("limit reached" in o for o in outcomes), 2, outcomes)
        self.assertEqual(runner.admission_count(self.state, "t1"), 3)

    def test_32_historical_release_survives_live_input_changes_and_project_removal(self):
        self.accept(); self.call("promote", run="r1", release="release1")
        self.source.write_text("Different source")
        (self.project / "tasks/t1.json").write_text("Invalid current task")
        (self.project / "qa/playbook.md").write_text("New rubric")
        self.assertEqual(runner.execute("verify-release", state=self.state, release="release1")["status"], "verified")
        shutil.rmtree(self.project)
        self.assertEqual(runner.execute("verify-release", state=self.state, release="release1")["status"], "verified")

    def test_33_release_and_history_tampering_are_detected(self):
        self.accept(); self.call("promote", run="r1", release="release1")
        paths = [self.state / "releases/release1/artifacts/report.md",
                 self.state / "releases/release1/inputs/controller/knowledge.py",
                 self.state / "runs/r1/receipt.json",
                 self.state / "registrations/t1.json"]
        for path in paths:
            original = path.read_bytes()
            with self.subTest(path=str(path)):
                path.write_bytes(original + b"\n")
                with self.assertRaises(runner.HarnessError):
                    runner.execute("verify-release", state=self.state, release="release1")
                path.write_bytes(original)

    def make_knowledge(self):
        self.task["modules"] = ["sources", "knowledge"]
        self.save(self.project / "tasks/t1.json", self.task)
        wiki = self.project / "wiki"; (wiki / "topics").mkdir(parents=True)
        (wiki / "index.md").write_text("# Index\n[Widget](topics/widget.md)\n")
        (wiki / "topics/widget.md").write_text("# Widget\nSee [[S1:L1-L1]].\n")
        claim = {"id": "C1", "text": "The widget supports 20 users.", "status": "supported",
                 "sources": [{"id": "S1", "sha256": self.manifest["sources"][0]["sha256"],
                              "start_line": 1, "end_line": 1}], "supersedes": []}
        (wiki / "claims.jsonl").write_text(json.dumps(claim) + "\n")
        return wiki

    def test_34_knowledge_is_captured_then_linted_and_published(self):
        wiki = self.make_knowledge()
        receipt = self.accept()
        self.assertIsNotNone(receipt["knowledge_sha256"])
        self.assertEqual(receipt["checks"][-1]["id"], "knowledge-lint")
        (wiki / "claims.jsonl").write_text("Bad live knowledge after evaluation")
        self.call("promote", run="r1", release="release1")
        released = self.state / "releases/release1/inputs/wiki"
        self.assertEqual(runner.tree_digest(released), receipt["knowledge_sha256"])
        self.assertEqual(runner.execute("verify-release", state=self.state, release="release1")["status"], "verified")

    def test_35_knowledge_failure_blocks_release_but_disabled_module_is_ignored(self):
        wiki = self.make_knowledge()
        (wiki / "claims.jsonl").write_text("not JSON")
        receipt = self.evaluate()
        self.assertEqual(receipt["status"], "fail")
        with self.assertRaisesRegex(runner.HarnessError, "hard checks"):
            self.call("promote", run="r1", release="release1")
        self.task["task_id"] = "t2"; self.task["modules"] = ["sources"]
        self.save(self.project / "tasks/t2.json", self.task)
        self.call("register", task="t2")
        self.assertEqual(self.call("evaluate", task="t2", candidate="c1", run="r2")["status"], "pass")

    def test_36_frozen_knowledge_tampering_blocks_promotion(self):
        self.make_knowledge(); self.accept()
        (self.state / "runs/r1/inputs/wiki/claims.jsonl").write_text("changed")
        with self.assertRaisesRegex(runner.HarnessError, "frozen inputs changed"):
            self.call("promote", run="r1", release="release1")

    def test_37_doctor_is_nonmutating_and_requires_valid_schema(self):
        before = runner.tree_digest(self.project)
        result = self.call("doctor", task="t1")
        self.assertEqual(result["status"], "ready")
        self.assertFalse(self.state.exists())
        self.assertEqual(before, runner.tree_digest(self.project))
        self.task["profile"] = "unsupported"
        self.save(self.project / "tasks/t1.json", self.task)
        with self.assertRaisesRegex(runner.HarnessError, "unsupported profile"):
            self.call("doctor", task="t1")

    def test_38_admission_corruption_is_not_silent(self):
        self.accept(); self.call("promote", run="r1", release="release1")
        admission = self.state / "runs/r1/admission.json"
        data = json.loads(admission.read_text()); data["ordinal"] = 99
        self.save(admission, data)
        with self.assertRaisesRegex(runner.HarnessError, "admission and receipt"):
            runner.execute("verify-release", state=self.state, release="release1")
        admission.unlink()
        with self.assertRaisesRegex(runner.HarnessError, "incomplete admission history"):
            self.call("evaluate", task="t1", candidate="c1", run="r2")

    def test_39_knowledge_executes_pinned_source_not_stale_bytecode(self):
        controller = Path(self.temp.name) / "controller"; controller.mkdir()
        path = controller / "knowledge.py"
        old = "def lint_knowledge(wiki, manifest, sources):\n    return ['cached-path']\n"
        new = old.replace("cached-path", "source-path")
        path.write_text(old)
        old_stat = path.stat()
        py_compile.compile(str(path), doraise=True, invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP)
        path.write_text(new)
        os.utime(path, ns=(old_stat.st_atime_ns, old_stat.st_mtime_ns))
        # Demonstrate the timestamp/size cache premise, then test our source loader.
        stale_spec = importlib.util.spec_from_file_location("cache_demo", path)
        stale_module = importlib.util.module_from_spec(stale_spec)
        stale_spec.loader.exec_module(stale_module)
        self.assertEqual(stale_module.lint_knowledge(None, None, None), ["cached-path"])
        with patch.object(runner, "CONTROLLER_ROOT", controller):
            result = runner.run_knowledge(None, None, None)
        self.assertEqual(result["messages"], ["source-path"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
