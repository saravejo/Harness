#!/usr/bin/env python3
"""Run the delivered test suite; does not need an LLM API or installed runtime."""
from pathlib import Path
import sys
import unittest

directory = Path(__file__).resolve().parent
suite = unittest.defaultTestLoader.discover(str(directory), pattern="test_*.py")
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
