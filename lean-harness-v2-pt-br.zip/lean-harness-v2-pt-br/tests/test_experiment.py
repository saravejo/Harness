"""Executed subprocess tests; fixture proposers are deterministic, not LLMs."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import time
import unittest

MODULE = Path(__file__).resolve().parents[1] / "controller" / "experiment.py"
spec = importlib.util.spec_from_file_location("harness_experiment", MODULE)
experiment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(experiment)


@unittest.skipUnless(os.name == "posix", "requires POSIX process groups")
class ExperimentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.baseline = self.root / "baseline"
        self.baseline.mkdir()
        (self.baseline / "score.txt").write_text("10")
        (self.baseline / "fixed.txt").write_text("preserve me")
        self.proposer = self.root / "proposer.py"
        self.evaluator = self.root / "evaluate.py"
        self.evaluator.write_text("import json, pathlib\nv=float(pathlib.Path('score.txt').read_text())\nprint(json.dumps({'valid':True,'metric':v}))\n")
        self.config = {"schema_version": 1, "goal": "minimize score", "baseline": "baseline",
                       "mutable_files": ["score.txt"],
                       "proposer": [sys.executable, str(self.proposer)],
                       "evaluator": [sys.executable, str(self.evaluator)],
                       "evaluator_inputs": [str(self.evaluator)],
                       "direction": "min", "min_delta": 0, "max_experiments": 3,
                       "command_timeout_seconds": 2, "total_timeout_seconds": 10}
        self.config_path = self.root / "config.json"
        self.state = self.root / "state"
        self.plans([8, 12, 7])

    def tearDown(self):
        self.temp.cleanup()

    def plans(self, scores):
        plans = [{"hypothesis": "try " + str(s), "files": {"score.txt": str(s)}} for s in scores]
        self.proposer.write_text("import json,sys\np=json.load(sys.stdin)\nplans=" + repr(plans) + "\nprint(json.dumps(plans[p['iteration']-1]))\n")

    def run_loop(self):
        self.config_path.write_text(json.dumps(self.config))
        return experiment.run(self.config_path, self.state)

    def records(self):
        return [json.loads(line) for line in (self.state / "events.jsonl").read_text().splitlines()]

    def outcomes(self):
        return [x for x in self.records() if x["event"] == "experiment_completed"]

    def test_01_real_subprocess_improve_regress_improve(self):
        result = self.run_loop()
        self.assertEqual(result["baseline_metric"], 10)
        self.assertEqual(result["best_metric"], 7)
        self.assertEqual([x["status"] for x in self.outcomes()], ["keep", "discard", "keep"])
        self.assertEqual((Path(result["best_path"]) / "score.txt").read_text(), "7")
        self.assertEqual((self.baseline / "score.txt").read_text(), "10")
        self.assertEqual((Path(result["best_path"]) / "fixed.txt").read_text(), "preserve me")
        # The next proposal sees the retained winner, never the discarded regression.
        context = json.loads((self.state / "logs/0003-propose.stdin.json").read_text())
        self.assertEqual(context["files"]["score.txt"], "8")
        self.assertEqual(context["best_metric"], 8)

    def test_02_max_direction(self):
        self.config["direction"] = "max"
        self.plans([11, 9, 14])
        self.assertEqual(self.run_loop()["best_metric"], 14)

    def test_03_tie_and_min_delta_not_kept(self):
        self.plans(["10.0", 9.5, 9])
        self.config["min_delta"] = 0.5
        self.assertEqual(self.run_loop()["best_metric"], 9)
        self.assertEqual([x["status"] for x in self.outcomes()], ["discard", "discard", "keep"])

    def test_04_unchanged_proposal_skips_evaluation(self):
        self.plans([10, 10, 10])
        self.run_loop()
        self.assertEqual([x["reason"] for x in self.outcomes()], ["no_change"] * 3)
        self.assertEqual(len([x for x in self.records() if x["event"] == "evaluation_started"]), 1)

    def test_05_malformed_proposer_never_passes(self):
        self.proposer.write_text("print('not json')")
        self.assertEqual(self.run_loop()["best_metric"], 10)
        self.assertEqual([x["reason"] for x in self.outcomes()], ["malformed"] * 3)

    def test_06_out_of_scope_change_rejected(self):
        self.proposer.write_text("import json\nprint(json.dumps({'hypothesis':'cheat','files':{'fixed.txt':'changed'}}))")
        self.run_loop()
        self.assertEqual(self.outcomes()[0]["reason"], "invalid_proposal")

    def test_07_traversal_change_rejected(self):
        self.proposer.write_text("import json\nprint(json.dumps({'hypothesis':'escape','files':{'../pwned':'x'}}))")
        self.run_loop()
        self.assertFalse((self.state / "candidates/pwned").exists())
        self.assertEqual(self.outcomes()[0]["reason"], "invalid_proposal")

    def test_08_candidate_crash_discarded_with_feedback(self):
        self.plans(["invalid", 8, 7])
        result = self.run_loop()
        self.assertEqual(result["best_metric"], 7)
        self.assertEqual(self.outcomes()[0]["reason"], "crash")
        context = json.loads((self.state / "logs/0002-propose.stdin.json").read_text())
        self.assertIn("ValueError", context["history"][0]["feedback"])

    def test_09_nan_never_passes(self):
        self.plans(["nan", "inf", "-inf"])
        self.assertEqual(self.run_loop()["best_metric"], 10)
        self.assertEqual([x["reason"] for x in self.outcomes()], ["malformed"] * 3)

    def test_10_invalid_metric_rejected(self):
        self.evaluator.write_text("import json,pathlib\nv=float(pathlib.Path('score.txt').read_text())\nprint(json.dumps({'valid':v==10,'metric':v}))")
        self.assertEqual(self.run_loop()["best_metric"], 10)
        self.assertEqual(self.outcomes()[0]["reason"], "invalid")

    def test_11_missing_valid_field_rejected(self):
        self.evaluator.write_text("print('{\"metric\": 0}')")
        with self.assertRaises(experiment.CommandFailure):
            self.run_loop()
        self.assertFalse((self.state / "best.json").exists())
        self.assertEqual(self.records()[-1]["event"], "run_failed")

    def test_12_timeout_discards_and_counts_attempt(self):
        self.config["command_timeout_seconds"] = 0.15
        self.config["max_experiments"] = 1
        self.proposer.write_text("import time\ntime.sleep(10)")
        result = self.run_loop()
        self.assertEqual(result["experiments_completed"], 1)
        self.assertEqual(self.outcomes()[0]["reason"], "timeout")

    def test_13_total_time_budget_stops_more_attempts(self):
        self.config["total_timeout_seconds"] = 0.2
        self.proposer.write_text("import time\ntime.sleep(10)")
        result = self.run_loop()
        self.assertEqual(result["stop_reason"], "time_limit")
        self.assertLess(result["experiments_completed"], 3)

    def test_14_reused_state_rejected(self):
        self.run_loop()
        with self.assertRaisesRegex(experiment.HarnessError, "new directory"):
            experiment.run(self.config_path, self.state)

    def test_15_baseline_symlink_rejected(self):
        (self.baseline / "link.txt").symlink_to(self.evaluator)
        with self.assertRaises(experiment.HarnessError):
            self.run_loop()
        self.assertFalse(self.state.exists())

    def test_16_evaluator_cannot_change_candidate(self):
        self.evaluator.write_text("from pathlib import Path\nPath('score.txt').write_text('0')\nprint('{\"valid\":true,\"metric\":0}')")
        with self.assertRaisesRegex(experiment.HarnessError, "modified its candidate"):
            self.run_loop()
        self.assertFalse((self.state / "best.json").exists())

    def test_17_evaluator_input_tampering_detected(self):
        self.proposer.write_text("from pathlib import Path\nPath(" + repr(str(self.evaluator)) + ").write_text('print(0)')\nprint('{}')")
        with self.assertRaisesRegex(experiment.HarnessError, "fixed input changed"):
            self.run_loop()
        self.assertEqual(json.loads((self.state / "best.json").read_text())["metric"], 10)

    def test_18_new_mutable_file_supported(self):
        self.config["mutable_files"].append("nested/new.txt")
        self.proposer.write_text("import json\nprint(json.dumps({'hypothesis':'new helper','files':{'score.txt':'8','nested/new.txt':'hello'}}))")
        result = self.run_loop()
        self.assertEqual((Path(result["best_path"]) / "nested/new.txt").read_text(), "hello")

    def test_19_duplicate_json_key_rejected(self):
        with self.assertRaisesRegex(experiment.HarnessError, "duplicate"):
            experiment.strict_json('{"a":1,"a":2}')

    def test_20_boolean_metric_rejected(self):
        with self.assertRaises(experiment.CommandFailure):
            experiment.metric_result({"valid": True, "metric": False})

    def test_21_empty_evaluator_inputs_rejected(self):
        self.config["evaluator_inputs"] = []
        with self.assertRaises(experiment.HarnessError):
            self.run_loop()

    def test_22_state_under_baseline_rejected(self):
        self.state = self.baseline / "state"
        with self.assertRaisesRegex(experiment.HarnessError, "disjoint"):
            self.run_loop()

    def test_23_unsafe_mutable_paths_rejected(self):
        self.config["mutable_files"] = ["../out.txt"]
        with self.assertRaises(experiment.HarnessError):
            self.run_loop()

    def test_24_invalid_config_number_rejected(self):
        self.config["max_experiments"] = True
        with self.assertRaises(experiment.HarnessError):
            self.run_loop()

    def test_25_evaluator_inside_baseline_rejected(self):
        self.evaluator = self.baseline / "evaluate.py"
        self.evaluator.write_text("print('{}')")
        self.config["evaluator"] = [sys.executable, str(self.evaluator)]
        self.config["evaluator_inputs"] = [str(self.evaluator)]
        with self.assertRaisesRegex(experiment.HarnessError, "outside baseline"):
            self.run_loop()

    def test_26_admission_record_precedes_work(self):
        self.run_loop()
        records = self.records()
        starts = [i for i, e in enumerate(records) if e["event"] == "experiment_started"]
        finishes = [i for i, e in enumerate(records) if e["event"] == "experiment_completed"]
        self.assertEqual(len(starts), 3)
        self.assertTrue(all(s < f for s, f in zip(starts, finishes)))

    def test_27_false_valid_string_rejected(self):
        with self.assertRaises(experiment.CommandFailure):
            experiment.metric_result({"valid": "true", "metric": 0})

    def test_28_unknown_schema_fields_rejected(self):
        self.config["resume"] = True
        with self.assertRaises(experiment.HarnessError):
            self.run_loop()

    def test_29_timeout_kills_descendant_process(self):
        marker = self.root / "orphan-marker"
        child = "import time; from pathlib import Path; time.sleep(0.5); Path(" + repr(str(marker)) + ").write_text('orphan')"
        self.proposer.write_text("import subprocess,sys,time\nsubprocess.Popen([sys.executable,'-c'," + repr(child) + "])\ntime.sleep(10)")
        self.config["command_timeout_seconds"] = 0.15
        self.config["max_experiments"] = 1
        self.run_loop()
        time.sleep(0.6)
        self.assertFalse(marker.exists())

    def test_30_failed_baseline_prevents_proposals(self):
        self.evaluator.write_text("raise RuntimeError('baseline broken')")
        with self.assertRaises(experiment.CommandFailure):
            self.run_loop()
        self.assertFalse((self.state / "logs/0001-propose.stdin.json").exists())
        self.assertFalse((self.state / "best.json").exists())

    def test_31_unrepresentable_metric_rejected(self):
        with self.assertRaises(experiment.CommandFailure):
            experiment.metric_result({"valid": True, "metric": 10 ** 500})

    def test_32_claude_result_envelope_parser(self):
        module = MODULE.with_name("claude_proposer.py")
        adapter_spec = importlib.util.spec_from_file_location("claude_proposer_test", module)
        adapter = importlib.util.module_from_spec(adapter_spec)
        adapter_spec.loader.exec_module(adapter)
        proposal = {"hypothesis": "test", "files": {"score.txt": "9"}}
        self.assertEqual(adapter.unwrap({"result": json.dumps(proposal)}), proposal)
        self.assertEqual(adapter.unwrap({"structured_output": proposal}), proposal)
        with self.assertRaises(ValueError):
            adapter.unwrap({"is_error": True, "result": "denied"})

    def test_33_sigterm_cleans_up_active_child(self):
        marker = self.root / "active-pid"
        self.evaluator.write_text("import os,time\nfrom pathlib import Path\nPath(" + repr(str(marker)) + ").write_text(str(os.getpid()))\ntime.sleep(30)")
        self.config_path.write_text(json.dumps(self.config))
        process = subprocess.Popen([sys.executable, "-I", str(MODULE), "run", "--config",
                                    str(self.config_path), "--state", str(self.state)],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            deadline = time.monotonic() + 5
            while not marker.exists() and time.monotonic() < deadline:
                time.sleep(0.02)
            self.assertTrue(marker.exists())
            child_pid = int(marker.read_text())
            process.terminate()
            process.communicate(timeout=5)
            with self.assertRaises(ProcessLookupError):
                os.kill(child_pid, 0)
            self.assertEqual(self.records()[-1]["status"], "interrupted")
            self.assertFalse((self.state / "best.json").exists())
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()

    def test_34_invalid_unicode_hypothesis_discarded_before_apply(self):
        self.proposer.write_text("import json\nprint(json.dumps({'hypothesis':chr(0xd800),'files':{'score.txt':'0'}}))")
        result = self.run_loop()
        self.assertEqual(result["best_metric"], 10)
        self.assertEqual([x["reason"] for x in self.outcomes()], ["invalid_proposal"] * 3)
        self.assertFalse((self.state / "candidates/0001").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
