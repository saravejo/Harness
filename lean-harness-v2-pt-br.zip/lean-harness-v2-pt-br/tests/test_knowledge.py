"""Structural knowledge regression tests. No semantic-judge or live-isolation claim."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / "controller" / "knowledge.py"
spec = importlib.util.spec_from_file_location("harness_knowledge_tests", MODULE)
knowledge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(knowledge)


class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.wiki = self.base / "wiki"
        (self.wiki / "topics").mkdir(parents=True)
        (self.wiki / "index.md").write_text("# Index\n[Widget](topics/widget.md)\n")
        (self.wiki / "topics/widget.md").write_text("# Widget\n[Back](../index.md)\n")
        self.source = b"A widget supports 20 users.\nIts color is blue.\n"
        self.sha = hashlib.sha256(self.source).hexdigest()
        self.manifest = {"sources": [{"id": "S1", "path": "sources/widget.txt", "sha256": self.sha}]}
        self.sources = {"S1": self.source}
        self.claim = {"id": "C1", "text": "A widget supports 20 users.", "status": "supported",
                      "sources": [{"id": "S1", "sha256": self.sha, "start_line": 1, "end_line": 1}],
                      "supersedes": []}
        self.write_claims([self.claim])

    def tearDown(self):
        self.temp.cleanup()

    def write_claims(self, claims):
        (self.wiki / "claims.jsonl").write_text("\n".join(json.dumps(x) for x in claims) + "\n")

    def lint(self):
        return knowledge.lint_knowledge(self.wiki, self.manifest, self.sources)

    def assertDiagnostic(self, fragment):
        diagnostics = self.lint()
        self.assertTrue(any(fragment in item for item in diagnostics), diagnostics)

    def test_01_valid_claim_and_index_pass(self):
        self.assertEqual(self.lint(), [])

    def test_02_source_summaries_are_optional(self):
        self.assertFalse((self.wiki / "sources").exists())
        self.assertEqual(self.lint(), [])

    def test_03_valid_locator_does_not_prove_truth(self):
        self.claim["text"] = "A widget supports 999 users."
        self.write_claims([self.claim])
        self.assertEqual(self.lint(), [])  # Intentional semantic counterexample.

    def test_04_missing_required_wiki_files(self):
        for name in ("index.md", "claims.jsonl"):
            with self.subTest(name=name):
                path = self.wiki / name
                data = path.read_bytes()
                path.unlink()
                self.assertDiagnostic("missing required wiki file: " + name)
                path.write_bytes(data)

    def test_05_malformed_json_and_duplicate_json_keys(self):
        for text, fragment in (("{broken", "claims.jsonl:1"), ('{"id":"C1","id":"C2"}', "duplicate JSON key")):
            with self.subTest(text=text):
                (self.wiki / "claims.jsonl").write_text(text)
                self.assertDiagnostic(fragment)

    def test_06_duplicate_claim_ids(self):
        self.write_claims([self.claim, self.claim])
        self.assertDiagnostic("duplicate claim ID")

    def test_07_unknown_keys_and_wrong_types(self):
        variants = [{**self.claim, "confidence": 0.9}, {**self.claim, "text": " "},
                    {**self.claim, "id": True}, {**self.claim, "sources": "S1"},
                    {**self.claim, "status": "verified"}, {**self.claim, "supersedes": None}]
        for claim in variants:
            with self.subTest(claim=claim):
                self.write_claims([claim])
                self.assertNotEqual(self.lint(), [])

    def test_08_supported_requires_source_assumption_does_not(self):
        self.claim["sources"] = []
        self.write_claims([self.claim])
        self.assertDiagnostic("supported claim requires a source")
        self.claim["status"] = "assumption"
        self.write_claims([self.claim])
        self.assertEqual(self.lint(), [])

    def test_09_unknown_source_and_mismatched_reference_hash(self):
        self.claim["sources"][0]["id"] = "missing"
        self.write_claims([self.claim])
        self.assertDiagnostic("unknown source ID")
        self.claim["sources"][0]["id"] = "S1"
        self.claim["sources"][0]["sha256"] = "0" * 64
        self.write_claims([self.claim])
        self.assertDiagnostic("source reference hash mismatch")

    def test_10_reference_bounds_and_strict_integer_types(self):
        for start, end in ((0, 1), (2, 1), (1, 3), (True, 1), (1, 1.0)):
            with self.subTest(start=start, end=end):
                self.claim["sources"][0].update(start_line=start, end_line=end)
                self.write_claims([self.claim])
                self.assertDiagnostic("invalid source locator")

    def test_11_frozen_source_mismatch_and_missing_source(self):
        self.sources["S1"] = b"Changed bytes"
        self.assertDiagnostic("frozen source hash mismatch")
        del self.sources["S1"]
        self.assertDiagnostic("frozen source missing")

    def test_12_extra_frozen_source_rejected(self):
        self.sources["S2"] = b"unregistered"
        self.assertDiagnostic("frozen source IDs do not match manifest")

    def test_13_binary_source_cannot_receive_text_locator(self):
        self.sources["S1"] = b"\xff\x00"
        binary_sha = hashlib.sha256(self.sources["S1"]).hexdigest()
        self.manifest["sources"][0]["sha256"] = binary_sha
        self.claim["sources"][0]["sha256"] = binary_sha
        self.write_claims([self.claim])
        self.assertDiagnostic("invalid source locator")

    def test_14_supersession_missing_self_and_duplicate(self):
        for supersedes, fragment in ((["missing"], "unknown supersession target"),
                                      (["C1"], "self-supersession forbidden"),
                                      (["C2", "C2"], "duplicate supersession target")):
            with self.subTest(supersedes=supersedes):
                self.claim["supersedes"] = supersedes
                self.write_claims([self.claim])
                self.assertDiagnostic(fragment)

    def test_15_supersession_cycle_rejected(self):
        first = {**self.claim, "supersedes": ["C2"]}
        second = {**self.claim, "id": "C2", "supersedes": ["C3"]}
        third = {**self.claim, "id": "C3", "supersedes": ["C1"]}
        self.write_claims([first, second, third])
        self.assertDiagnostic("supersession cycle")

    def test_16_acyclic_supersession_with_shared_ancestor_passes(self):
        claims = [{**self.claim, "id": "C1", "supersedes": []},
                  {**self.claim, "id": "C2", "supersedes": ["C1"]},
                  {**self.claim, "id": "C3", "supersedes": ["C1"]},
                  {**self.claim, "id": "C4", "supersedes": ["C2", "C3"]}]
        self.write_claims(claims)
        self.assertEqual(self.lint(), [])

    def test_17_index_must_cover_topics_and_existing_summaries(self):
        (self.wiki / "topics/unlisted.md").write_text("# Unlisted\n")
        (self.wiki / "sources").mkdir()
        (self.wiki / "sources/summary.md").write_text("# Summary\n")
        diagnostics = self.lint()
        self.assertIn("index.md: missing page link: topics/unlisted.md", diagnostics)
        self.assertIn("index.md: missing page link: sources/summary.md", diagnostics)

    def test_18_broken_relative_links(self):
        (self.wiki / "topics/widget.md").write_text("[Missing](../topics/missing.md)\n")
        self.assertDiagnostic("broken local link")

    def test_19_links_cannot_escape_wiki(self):
        (self.base / "outside.md").write_text("outside")
        for target in ("../../outside.md", "/etc/passwd", "..%2f..%2foutside.md", "file:///etc/passwd", "javascript:alert(1)"):
            with self.subTest(target=target):
                (self.wiki / "topics/widget.md").write_text(f"[Bad]({target})\n")
                self.assertNotEqual(self.lint(), [])

    def test_20_fragments_and_external_links_not_semantically_checked(self):
        (self.wiki / "topics/widget.md").write_text('[Back](../index.md#nonexistent-heading)\n[Remote](https://example.invalid/missing)\n')
        self.assertEqual(self.lint(), [])  # Deliberately documented scope.

    def test_21_code_examples_are_not_treated_as_links(self):
        (self.wiki / "topics/widget.md").write_text('```md\n[Missing](gone.md)\n```\n`[Missing](gone.md)`\n')
        self.assertEqual(self.lint(), [])

    def test_22_unsupported_reference_and_html_links_fail_explicitly(self):
        for content in ('[Missing][ref]\n[ref]: gone.md\n', '<a href="gone.md">Missing</a>'):
            with self.subTest(content=content):
                (self.wiki / "topics/widget.md").write_text(content)
                self.assertDiagnostic("unsupported")

    def test_23_symlink_file_or_ancestor_rejected(self):
        (self.wiki / "escape.md").symlink_to(self.base / "outside.md")
        self.assertDiagnostic("symlink forbidden")
        (self.wiki / "escape.md").unlink()
        alias = self.base / "alias"
        alias.symlink_to(self.wiki, target_is_directory=True)
        result = knowledge.lint_knowledge(alias, self.manifest, self.sources)
        self.assertTrue(result)
        self.assertIn("knowledge input error", result[0])

    def test_24_resource_bound_rejected(self):
        with patch.object(knowledge, "MAX_FILE_BYTES", 10):
            self.assertDiagnostic("exceeds byte limit")

    def test_25_empty_claims_do_not_establish_semantic_coverage(self):
        (self.wiki / "claims.jsonl").write_text("")
        (self.wiki / "topics/widget.md").write_text("The widget has an unsupported claim.\n")
        self.assertEqual(self.lint(), [])

    def test_26_only_supplied_frozen_sources_are_used(self):
        live_raw = self.base / "raw/sources"
        live_raw.mkdir(parents=True)
        (live_raw / "widget.txt").write_text("A later, different source revision")
        self.assertEqual(self.lint(), [])

    def test_27_utf8_and_duplicate_source_locators(self):
        (self.wiki / "claims.jsonl").write_bytes(b"\xff")
        self.assertDiagnostic("invalid UTF-8")
        self.claim["sources"].append(dict(self.claim["sources"][0]))
        self.write_claims([self.claim])
        self.assertDiagnostic("duplicate source locator")

    def test_28_direct_index_link_with_angle_target_and_title(self):
        (self.wiki / "index.md").write_text('[Widget](<topics/widget.md> "Overview")\n')
        self.assertEqual(self.lint(), [])

    def test_29_long_acyclic_supersession_chain_avoids_recursion_limit(self):
        claims = []
        for number in range(1200):
            claims.append({**self.claim, "id": f"C{number}", "supersedes": [f"C{number + 1}"] if number < 1199 else []})
        self.write_claims(claims)
        self.assertEqual(self.lint(), [])

    def test_30_ids_match_controller_source_id_grammar(self):
        self.manifest["sources"][0]["id"] = "1.source"
        self.sources = {"1.source": self.source}
        self.claim["id"] = "1.claim"
        self.claim["sources"][0]["id"] = "1.source"
        self.write_claims([self.claim])
        self.assertEqual(self.lint(), [])


if __name__ == "__main__":
    unittest.main()
