import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


PATH = Path(__file__).resolve().parents[1] / "controller" / "wiki_check.py"
SPEC = importlib.util.spec_from_file_location("wiki_check", PATH)
checker = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(checker)


class WikiCheckTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.project = Path(self.temp.name)
        (self.project / "raw").mkdir()
        (self.project / "wiki" / "topics").mkdir(parents=True)
        self.write("raw/manifest.json", '{"sources": []}')
        self.write("wiki/index.md", "# Index\n")
        self.write("wiki/claims.jsonl", "")

    def write(self, path, text):
        (self.project / path).write_text(text, encoding="utf-8")

    def source(self):
        data = b"The approved limit is 12.\n"
        self.write("raw/policy.txt", data.decode())
        digest = hashlib.sha256(data).hexdigest()
        self.write("raw/manifest.json", json.dumps({"sources": [{
            "id": "S1", "path": "policy.txt", "sha256": digest}]}))
        return digest

    def test_empty_scaffold_and_no_mutation(self):
        before = {str(p): p.read_bytes() for p in self.project.rglob("*") if p.is_file()}
        result = checker.check(self.project)
        self.assertEqual(result["status"], "pass")
        self.assertEqual(result["semantic_review"], "not-performed")
        self.assertEqual(before, {str(p): p.read_bytes() for p in self.project.rglob("*") if p.is_file()})

    def test_valid_cited_claim(self):
        digest = self.source()
        self.write("wiki/claims.jsonl", json.dumps({"id": "C1", "text": "Limit 12", "status": "supported", "sources": [
            {"id": "S1", "sha256": digest, "start_line": 1, "end_line": 1}], "supersedes": []}) + "\n")
        self.assertEqual(checker.check(self.project)["status"], "pass")

    def test_source_tampering_rejected(self):
        self.source()
        self.write("raw/policy.txt", "The limit changed.\n")
        self.assertEqual(checker.check(self.project)["status"], "fail")

    def test_unlisted_source_rejected(self):
        self.write("raw/policy.txt", "Evidence\n")
        self.assertEqual(checker.check(self.project)["status"], "fail")

    def test_unindexed_topic_rejected(self):
        self.write("wiki/topics/topic.md", "# Topic\n")
        self.assertEqual(checker.check(self.project)["status"], "fail")

    def test_symlink_rejected(self):
        (self.project / "wiki" / "escape.md").symlink_to(self.project / "raw" / "manifest.json")
        self.assertEqual(checker.check(self.project)["status"], "fail")

    def test_invalid_locator_rejected(self):
        digest = self.source()
        self.write("wiki/claims.jsonl", json.dumps({"id": "C1", "text": "Limit 12", "status": "supported", "sources": [
            {"id": "S1", "sha256": digest, "start_line": 1, "end_line": 99}], "supersedes": []}) + "\n")
        self.assertEqual(checker.check(self.project)["status"], "fail")

    def test_memory_must_be_reachable_from_index(self):
        self.write("wiki/memory.md", "# Memory\n")
        result = checker.check(self.project)
        self.assertEqual(result["status"], "fail")
        self.assertIn("wiki page unreachable from index.md: memory.md", result["diagnostics"])
        self.write("wiki/index.md", "# Index\n[Memory](memory.md)\n")
        self.assertEqual(checker.check(self.project)["status"], "pass")

    def test_unreachable_cycle_is_not_navigation(self):
        self.write("wiki/a.md", "# A\n[B](b.md)\n")
        self.write("wiki/b.md", "# B\n[A](a.md)\n")
        self.assertEqual(checker.check(self.project)["status"], "fail")
        self.write("wiki/index.md", "# Index\n[A](a.md)\n")
        self.assertEqual(checker.check(self.project)["status"], "pass")


if __name__ == "__main__":
    unittest.main()
