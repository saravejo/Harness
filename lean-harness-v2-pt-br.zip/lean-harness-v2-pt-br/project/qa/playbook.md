# Revisão vinculada às evidências

Leia o contrato da tarefa registrada, as evidências de origem vinculadas por hashes,
os resultados das verificações obrigatórias e a cópia capturada do candidato. Não
a substitua pelo candidato mutável em trabalho. Evite o histórico do agente gerador
quando ele for desnecessário; um contexto novo é uma medida de mitigação, não uma
prova de julgamento independente. Inspecione cada citação para conferir se a fonte
sustenta a afirmação.

Para cada critério obrigatório, retorne pass, fail ou unknown com evidências.
Para uma omissão, cite o ID do requisito e o escopo inspecionado; não é possível
nem necessário citar um texto ausente. Para uma afirmação falsa, cite o candidato
e a fonte. Todos os critérios obrigatórios precisam passar. Resultados ausentes,
desconhecidos ou falhas críticas bloqueiam a entrega. Pontuações de preferência
não compensam o descumprimento de um requisito.

Nas comparações opcionais entre dois candidatos, oculte sua identidade e inverta
a ordem de apresentação. Uma preferência inconsistente indica resultado não
resolvido ou empate. Uma preferência consistente ainda não comprova que qualquer
um dos candidatos atenda aos critérios absolutos de aceitação.

Os revisores devem ter autoridade e conhecimento do domínio suficientes para a
tarefa. O nome do revisor no JSON é um rótulo, não uma autenticação; o canal de
submissão controlado delimita a confiança. Um contexto separado de chamada de
ferramenta, por si só, não estabelece independência.

O executor de referência valida a estrutura do registro de avaliação, a cobertura
dos critérios obrigatórios e o vínculo com a cópia capturada. Ele não pode validar
o raciocínio ou a honestidade do revisor. Nenhuma quantidade de personas, limite
de duas rodadas ou limiar de cinco minutos é um padrão universal.
