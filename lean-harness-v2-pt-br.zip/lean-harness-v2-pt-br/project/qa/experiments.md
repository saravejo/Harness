# Experimentos autônomos com limites definidos

Leia este arquivo somente para uma tarefa de otimização iterativa. O agente define
experimentos específicos para a tarefa; `controller/experiment.py` executa o ciclo
de medição e decisão entre manter ou descartar. Não inicie um processo interminável
em segundo plano nem exija que o usuário conclua uma demonstração.

## Definir o experimento

1. Traduza o objetivo real do usuário em uma métrica observável, seu sentido de
   melhoria e verificações de validade inegociáveis. Reutilize um avaliador
   existente que seja aplicável. Uma métrica indireta exige que sua limitação seja
   explicitada; uma nota de preferência de LLM sem explicação não é evidência
   objetiva. Pergunte somente quando objetivos materialmente diferentes não
   puderem ser resolvidos pelo contexto. Para edições comuns sem uma métrica útil,
   conclua a tarefa e verifique os requisitos, em vez de inventar uma otimização.
2. Fixe o avaliador, os dados de avaliação, os arquivos cuja edição é permitida, as
   sementes e repetições, a mudança mínima relevante e o orçamento antes de medir
   a versão inicial. Mantenha o avaliador e os dados fora do candidato mutável.
   Para medições ruidosas, defina previamente no avaliador a agregação e as
   repetições; não selecione apenas uma execução favorável. Se houver um conjunto
   reservado, use-o para validação final, não para selecionar propostas.
3. Use o orçamento do usuário. Caso ele não tenha sido definido, informe um padrão
   modesto de três propostas, 60 segundos por comando e 300 segundos no total,
   incluindo a avaliação da versão inicial. Esses são limites de parada
   configuráveis, não afirmações sobre o esforço ideal de busca. Conte propostas
   malsucedidas, resultados inválidos e falhas de execução; não repita as tentativas
   indefinidamente.
4. Faça o agente criar uma configuração mínima e específica para a tarefa somente
   quando necessário, por exemplo `results/candidates/<task>/experiment.json`.
   A versão inicial contém apenas insumos e artefatos relevantes; copie o trabalho
   existente do usuário, nunca redefina sua branch. Comandos são arrays de argv,
   não strings interpoladas de shell. O diretório de estado deve ser novo e não
   pode se sobrepor ao da versão inicial. Não use um candidato como diretório do
   projeto de trabalho, do controlador, do estado confiável ou do avaliador.

A configuração contém exatamente estas chaves (os caminhos são resolvidos em
relação à pasta do arquivo de configuração; use caminhos reais e valores
específicos da tarefa):

```json
{
  "schema_version": 1,
  "goal": "The user's actual measurable objective and constraints",
  "baseline": "<baseline directory>",
  "mutable_files": ["<relative text artifact path>"],
  "proposer": ["<proposal program>", "<argument>"],
  "evaluator": ["<evaluation program>", "<argument>"],
  "evaluator_inputs": ["<actual evaluator/data file path>"],
  "direction": "min",
  "min_delta": 0,
  "max_experiments": 3,
  "command_timeout_seconds": 60,
  "total_timeout_seconds": 300
}
```

`direction` é `min` ou `max`. `max_experiments` não inclui a avaliação única da
versão inicial. Liste todos os arquivos de código e dados do avaliador em
`evaluator_inputs` para detectar alterações nos insumos listados; dependências
não listadas não são vinculadas automaticamente. `min_delta` é um limiar de
aceitação não negativo, não um teste de significância estatística. Não modifique
a configuração nem o critério de aceitação depois de observar os resultados.

## Executar sem pedidos repetidos de permissão

A partir de `project/`, execute o ciclo configurado:

```bash
python3 -I ../controller/experiment.py run --config <actual-config.json> --state <new-run-directory>
```

O proponente recebe JSON pela entrada padrão contendo o objetivo, a melhor métrica
atual, o conteúdo dos arquivos permitidos, a iteração e o histórico. Ele deve
retornar exatamente
`{"hypothesis":"A concrete expected improvement","files":{"allowed/path":"full new text"}}`.
Ele pode alterar somente os arquivos listados. O avaliador é executado em um
diretório separado para o candidato, identificado por `HARNESS_CANDIDATE`, e retorna
exatamente `{"valid":true,"metric":1.0}`; candidatos inválidos retornam `valid:false`
e podem usar `metric:null`. Inclua verificações de correção no avaliador; a métrica
isolada é insuficiente. Registros e textos de diagnóstico não devem corromper a
saída padrão JSON do avaliador.

O motor mede a versão inicial e depois repete: propor uma hipótese, criar um
candidato a partir do melhor atual, avaliar e manter somente uma melhoria válida
que ultrapasse o limiar configurado. Empates, regressões, saídas inválidas, falhas
de execução, estouros de tempo e propostas inseguras nunca se tornam a melhor
versão. Isso rejeita deliberadamente os empates mesmo quando um candidato é mais
simples; simplicidade não é uma exceção não medida ao contrato. Descartar significa
que a referência para a melhor versão permanece na cópia capturada anterior; não
é necessário redefinir destrutivamente o repositório do usuário. O ciclo termina
ao atingir o limite de propostas ou de tempo. Inspecione o resumo e a telemetria
reais; uma execução interrompida ou uma medição ausente não é um sucesso.
Diretórios de execução reutilizados são rejeitados; inspecione-os antes de iniciar
uma nova execução e nunca apague evidências de falhas.

É necessário disponibilizar um proponente externo, por modelo ou CLI, para gerar
propostas sem acompanhamento. O motor não contém um modelo nem fornece credenciais
de API. Se estiver usando uma sessão ativa do Claude Code sem um proponente
externo, realize o mesmo ciclo limitado dentro da sessão: registre o contrato e a
versão inicial fixados, altere somente os arquivos permitidos do candidato,
execute o avaliador real após cada proposta, registre o resultado e o estado e
mantenha somente a melhor versão medida. Informe que a orquestração foi feita
pelo agente, não por uma execução do motor. Nessa alternativa, não alegue
agendamento sem acompanhamento, orçamento imposto pelo motor ou telemetria imutável.

Com o Claude Code já instalado e autenticado, o adaptador incluído pode ser o
proponente: `["python3", "/absolute/path/to/controller/claude_proposer.py"]`.
Ele faz uma chamada nova em modo de impressão por proposta e solicita JSON sem
ferramentas. Mantenha os controles normais de autenticação e permissão; nenhum
parâmetro de contorno desses controles é necessário. A integração real com o
provedor não foi testada no ambiente de desenvolvimento fornecido. O subprocesso
do adaptador está sujeito ao limite de tempo por comando do motor. Caminhos em
argv que nomeiam arquivos existentes são resolvidos em relação à configuração;
use caminhos absolutos para ferramentas e dados e para argumentos que nomeiem
diretórios, a fim de evitar ambiguidades.

## Concluir e aprender

- Revalide a cópia escolhida em relação a todos os requisitos da tarefa e às
  verificações reservadas. Relate a versão inicial e a melhor, as tentativas reais,
  as verificações que falharam ou ficaram desconhecidas, as limitações da métrica e
  o motivo da parada. A versão inicial pode continuar sendo a vencedora.
- Entregue exatamente a cópia escolhida. Se o controle de entrega estiver
  configurado, submeta essa cópia às suas verificações e à revisão vinculada às
  evidências; a seleção de experimentos não contorna a aceitação nem publica
  automaticamente nada em serviços externos.
- Salve uma descoberta concisa e reutilizável por meio de `qa/wiki.md` somente
  quando ela for sustentada pelas evidências do experimento. Registre escopo,
  configuração e referências das execuções; preserve incertezas e hipóteses
  malsucedidas quando elas ajudarem a evitar erros repetidos.
- A execução do candidato e os subprocessos configurados usam as permissões de quem
  os chama. Copiar diretórios e verificar hashes não constituem isolamento do
  sistema operacional. Use um ambiente de execução efetivamente protegido para
  código não confiável ou quando for necessária maior resistência a adulterações.
