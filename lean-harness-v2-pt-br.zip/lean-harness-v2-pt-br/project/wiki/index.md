# Índice de conhecimento

- [Afirmações](claims.jsonl): estado das afirmações e referências às fontes.
- [Memória](memory.md): decisões ativas, lições aprendidas e histórico de alterações.

Adicione links para as páginas de tópicos quando elas forem criadas.
