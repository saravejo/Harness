# Memória operacional

## Decisões ativas

## Lições aprendidas

## Histórico de alterações
