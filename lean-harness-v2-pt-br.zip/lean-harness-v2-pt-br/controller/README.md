# Controladores do Lean harness v2

As instruções curtas do projeto direcionam o trabalho comum, o trabalho com a wiki
e a otimização mensurável, sem demonstração ou registro obrigatório de tarefas.
As rotinas completas da wiki e dos experimentos estão em `project/qa/wiki.md` e
`project/qa/experiments.md`; leia apenas o fluxo relevante para a tarefa.

- `experiment.py` executa um ciclo limitado: medição inicial, proposta, avaliação
  e decisão de manter ou descartar. Ele exige um avaliador específico para a
  tarefa e um comando que gere propostas em JSON. O adaptador opcional
  `claude_proposer.py` usa o CLI do Claude Code instalado e autenticado; uma chamada
  real ao provedor não foi testada neste ambiente. Nenhum modelo ou credencial está
  incluído. Como alternativa, o agente pode executar o ciclo documentado em sua
  sessão atual, sem alegar que os controles foram impostos pelo motor.
- `wiki_check.py` fornece uma verificação estrutural preliminar somente de leitura,
  sem registro. O LLM realiza a ingestão, a consulta, a síntese e a manutenção
  semântica conforme o fluxo da wiki. Uma aprovação estrutural não é uma revisão
  semântica.
- `runner.py` e `knowledge.py` mantêm a interface separada e opcional de controle
  de entrega descrita abaixo. O vencedor de um experimento não é uma entrega aceita.

São necessários Python 3.10+ e POSIX. Execute `python3 -I tests/run_tests.py` a partir
da raiz do pacote para rodar a suíte de testes completa. A execução dos candidatos
usa as permissões reais de quem a invoca: subprocessos, diretórios copiados e hashes
não constituem uma sandbox do sistema operacional.

## Controlador de entrega

O controlador de entrega implementa verificações estruturais vinculadas às cópias
capturadas e registra a aceitação da revisão. Ele não autentica revisores, não impõe
isolamento do sistema operacional, não julga a veracidade semântica, não executa o
código dos candidatos nem agenda chamadas de modelos. Implante o controlador e o
estado confiável sob uma identidade protegida de proprietário ou serviço. O agente
que realiza o trabalho não deve modificar nenhum dos dois nem executar operações
administrativas usando essa identidade.

Use Python 3.10+ em sistemas POSIX compatíveis. São necessários `flock`, abertura de
arquivos relativa a descritores e `O_NOFOLLOW`. Instale o diretório `controller/`
completo fora do projeto. Tanto `runner.py` quanto `knowledge.py` têm seus bytes
fixados por hash; a validação do conhecimento executa diretamente os bytes fixados
do código-fonte, ignorando o bytecode em cache. Proteja separadamente o ambiente de
execução do Python e as dependências. Os hashes não são assinaturas digitais.

## Comandos

Execute a partir de um shell ou serviço confiável. Estes caminhos são exemplos
ilustrativos e devem ser substituídos pelos caminhos reais:

```bash
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state doctor --task task-001
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state register --task task-001
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state evaluate --task task-001 --candidate candidate-001 --run run-001
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state review --run run-001 --file /protected/review.json
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state promote --run run-001 --release release-001
python3 -I /protected/controller/runner.py --state /protected/state verify-release --release release-001
```

O projeto, o diretório do controlador e o estado confiável devem ocupar diretórios
separados, sem sobreposição. `doctor` lê a configuração e verifica caminhos e
esquema sem criar estado. Uma verificação preliminar bem-sucedida não prova que a
sandbox ou as permissões dos conectores estejam sendo impostas. `verify-release`
não exige um projeto atual. As outras operações exigem.

## Esquema estrito da tarefa

Salve uma tarefa em `tasks/<task_id>.json` com exatamente estas chaves:

```json
{
  "schema_version": 2,
  "task_id": "task-001",
  "profile": "text-v2",
  "goal": "The complete semantic objective and required outcome.",
  "modules": ["sources", "knowledge"],
  "limits": {"max_evaluations": 3},
  "required_files": [
    {"path": "report.md", "headings": ["# Report"], "require_citations": true}
  ],
  "review_criteria": ["grounding", "completeness"]
}
```

As únicas seleções de módulos são `[]`, `["sources"]` e
`["sources", "knowledge"]`. O módulo de conhecimento exige fontes. Tarefas sem
fontes não carregam manifesto nem wiki; `require_citations` deve ser false e
marcadores de citação não são aceitos. Perfis desconhecidos, chaves extras,
identificadores duplicados e verificações vazias são rejeitados. Os caminhos dos
artefatos exigidos são relativos a `results/candidates/<candidate-id>/artifacts/`.
O conjunto de arquivos deve corresponder exatamente ao exigido.

O perfil verifica arquivos UTF-8 não vazios, linhas literais de títulos e
referências a fontes no formato `[[S1:L1-L2]]`, com números de linhas de texto
iniciados em um e limites inclusivos. Quando as fontes estão habilitadas,
`raw/manifest.json` tem exatamente esta estrutura:

```json
{"sources":[{"id":"S1","path":"sources/example.txt","sha256":"<actual SHA-256>"}]}
```

Todos os arquivos de raw, exceto o manifesto, devem ser listados, inclusive os
arquivos ocultos. Os caminhos são relativos a raw. A sintaxe de citação e os
localizadores válidos não provam que uma fonte sustenta uma afirmação, que todas
as afirmações têm citações ou que o resultado está completo.

O modo de conhecimento captura uma cópia de `wiki/` antes de chamar `knowledge.py`.
Ele verifica os arquivos obrigatórios `index.md`/`claims.jsonl`, as referências
estruturadas das afirmações, as relações de substituição e o subconjunto documentado
de links Markdown. Consulte `knowledge.py` para conhecer o formato e os limites
exatos. Resumos de fontes são opcionais. Defeitos da wiki sem relação com a tarefa
não podem bloqueá-la quando o módulo de conhecimento está desabilitado.

## Limites de avaliação e evidências

O registro fixa por hash os bytes da tarefa, o manifesto e o conteúdo das fontes
quando habilitados, a rubrica em `qa/playbook.md` e os dois arquivos de código-fonte
do controlador. Alterações relevantes nas entradas exigem um novo ID ou versão da
tarefa e um novo registro. As entradas capturadas da execução contêm a tarefa, a
rubrica, os arquivos do controlador e, opcionalmente, cópias de raw e da wiki.

O controlador serializa as admissões usando o bloqueio do estado confiável. Uma
avaliação admitida grava `admission.json` antes de copiar ou avaliar. O limite conta
todas as avaliações admitidas, inclusive reprovações, erros e execuções interrompidas
sem comprovante. Candidatos ausentes, registro desatualizado, IDs reutilizados e
outras falhas na verificação preliminar não consomem uma nova admissão. Um histórico
de admissões corrompido ou incompleto bloqueia novos trabalhos até que haja uma
recuperação confiável; o controlador nunca presume uma contagem menor. Esse limite
se aplica somente às avaliações, não às gerações de modelos, ao tempo, aos tokens
ou ao dinheiro.

IDs de execução e de entrega nunca são reutilizados. Uma avaliação concluída retém
um comprovante com resultado `pass`, `fail` ou `error`. O trabalho interrompido
continua visível por meio de sua admissão. Nenhuma verificação ausente, reprovada ou
de resultado desconhecido é tratada como aprovada.

## Revisão

O revisor confiável deve inspecionar o candidato capturado, o contrato completo, a
rubrica e as cópias congeladas das fontes e da wiki relevantes. Forneça exatamente:

```json
{
  "run_id":"run-001",
  "candidate_sha256":"<receipt value>",
  "contract_sha256":"<receipt value>",
  "reviewer":"<reviewer identity or service>",
  "criteria":[
    {"id":"grounding","status":"pass","evidence":"<actual inspected locations>"},
    {"id":"completeness","status":"pass","evidence":"<actual contract comparison>"}
  ]
}
```

Cada critério obrigatório deve aparecer exatamente uma vez; os status são `pass`,
`fail` ou `unknown`. A aprovação exige que todos os critérios tenham resultado pass.
As evidências não podem estar vazias, mas sua veracidade não é verificada por este
controlador. A identidade do revisor é um metadado, não uma identidade autenticada.
Não envie o autorrelato do agente que realiza o trabalho como revisão com autoridade
para aprovar a entrega.

## Promoção e verificação histórica

A promoção verifica as vinculações atuais por hash e a integridade da execução
congelada, copia os bytes avaliados para um diretório intermediário e renomeia esse
diretório atomicamente no mesmo sistema de arquivos. Um registro de publicação
protegido separadamente vincula a árvore da entrega e o histórico de registro,
comprovante, revisão e admissão. Uma falha entre a criação do registro de publicação
e a renomeação deixa uma publicação incompleta que não passa na verificação. Não há
garantia de durabilidade após falhas nem de atomicidade entre sistemas de arquivos.

`verify-release` verifica os bytes congelados dos artefatos e das entradas, a
aceitação histórica, a vinculação do controlador, da rubrica, do contrato, das fontes
e da wiki, e o histórico protegido. A verificação continua funcionando após
alterações legítimas no projeto atual ou a remoção do projeto. Ela detecta
adulterações da entrega ou do histórico cobertas pelas verificações, mas não prova
adequação atual, veracidade semântica, autenticidade do revisor ou segurança contra
alguém que controla todos os registros confiáveis. Preserve o estado histórico
protegido; não o exclua durante a limpeza dos candidatos.

A entrega oficial fica em `STATE/releases/<release-id>/`; o modelo não possui um
segundo diretório final mutável. A publicação externa é uma operação separada.

## Limites de recursos e testes

Cada entrada admite 10 MiB por arquivo, 50 MiB por árvore, 1000 arquivos, 5000 entradas
de diretório e 64 níveis de subdiretórios. Esses são limites da implementação de
referência, não valores ótimos ajustados. Links simbólicos, caminhos inseguros e
arquivos não regulares são rejeitados. Descritores de diretório impedem a condição
de corrida de leitura com link simbólico em um diretório ancestral que foi reproduzida.

Execute `python3 -I tests/run_tests.py` a partir da raiz do pacote. Os testes exercitam
o comportamento das verificações estruturais, das cópias capturadas, dos limites,
da revisão, dos módulos e da verificação histórica. Eles não medem a qualidade do
LLM nem comprovam o isolamento real da implantação.
