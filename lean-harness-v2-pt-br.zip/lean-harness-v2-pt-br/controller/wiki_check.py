#!/usr/bin/env python3
"""Read-only structural wiki check; semantic maintenance remains an LLM workflow.

No task registration or release is required. Checks a temporary captured copy,
not a transactionally consistent filesystem snapshot or an accepted release.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys
import tempfile


def _module(name):
    path = Path(__file__).resolve().with_name(name + ".py")
    spec = importlib.util.spec_from_file_location("lean_" + name, path)
    module = importlib.util.module_from_spec(spec)
    # Execute source, not a possibly stale bytecode cache.
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


def navigation_diagnostics(knowledge, wiki):
    """Require every Markdown page to be reachable from the wiki index.

    The release validator already enforces direct catalog links for topics and
    source summaries. This preflight also covers memory and other loose pages.
    It uses exactly the validator's supported inline-link syntax.
    """
    files = knowledge._read_tree(wiki)
    pages = {name for name in files if name.endswith(".md")}
    graph = {name: set() for name in pages}
    for page in pages:
        try:
            text = knowledge._without_code(files[page].decode("utf-8"))
        except UnicodeDecodeError:
            continue  # Existing validator emits this diagnostic.
        for match in re.finditer(r"!?\[[^\]\n]*\]\(([^)\n]*)\)", text):
            try:
                target = knowledge._local_target(page, knowledge._destination(match.group(1)))
                if target in pages:
                    graph[page].add(target)
            except (ValueError, TypeError):
                continue  # Existing validator emits malformed-link diagnostics.
    reached, pending = set(), ["index.md"]
    while pending:
        page = pending.pop()
        if page in reached:
            continue
        reached.add(page)
        pending.extend(graph.get(page, set()) - reached)
    return [f"wiki page unreachable from index.md: {page}" for page in sorted(pages - reached)]


def check(project):
    runner = _module("runner")
    knowledge = _module("knowledge")
    try:
        project = runner.root_path(project)
        with tempfile.TemporaryDirectory(prefix="lean-wiki-check-") as temp:
            captured = Path(temp)
            runner.copy_snapshot(project / "raw", captured / "raw")
            runner.copy_snapshot(project / "wiki", captured / "wiki")
            manifest = runner.load_json(captured / "raw" / "manifest.json")
            # An unused, empty wiki is valid; source-enabled release tasks still
            # require a nonempty source collection in the release controller.
            if manifest == {"sources": []}:
                runner.require(
                    [name for name, _ in runner.files_in(captured / "raw")] == ["manifest.json"],
                    "unlisted source file in empty manifest",
                )
            else:
                manifest, _ = runner.manifest_config(captured)
            source_bytes = {
                item["id"]: runner.read_bytes(captured / "raw" / item["path"])
                for item in manifest["sources"]
            }
            diagnostics = knowledge.lint_knowledge(captured / "wiki", manifest, source_bytes)
            diagnostics += navigation_diagnostics(knowledge, captured / "wiki")
    except (runner.HarnessError, OSError, ValueError, TypeError, KeyError, RecursionError) as exc:
        diagnostics = [str(exc)]
    return {
        "status": "fail" if diagnostics else "pass",
        "scope": "structural-only",
        "semantic_review": "not-performed",
        "diagnostics": diagnostics,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    args = parser.parse_args()
    result = check(args.project)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
