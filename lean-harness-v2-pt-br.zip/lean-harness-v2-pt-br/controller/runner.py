#!/usr/bin/env python3
"""Snapshot-bound structural QA reference; not an OS sandbox or semantic grader.

Run this trusted controller under a separate identity in deployment. The working
agent must not write this code, task/source pins, --state, or published releases.
No candidate code or shell commands are executed. See qa/README.md for limits.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
from types import ModuleType

IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
CITATION = re.compile(r"\[\[([A-Za-z0-9][A-Za-z0-9._-]{0,63}):L([1-9][0-9]*)-L([1-9][0-9]*)\]\]")
MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_FILES = 1000
MAX_TOTAL_BYTES = 50 * 1024 * 1024
MAX_ENTRIES = 5000
CONTROLLER_ROOT = Path(__file__).resolve().parent
BUNDLE_FILES = ("runner.py", "knowledge.py")
PIN_FIELDS = ("contract_sha256", "manifest_sha256", "evaluator_sha256", "rubric_sha256")


class HarnessError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise HarnessError(message)


def identifier(value):
    require(isinstance(value, str) and IDENTIFIER.fullmatch(value) is not None,
            "invalid identifier")
    return value


def keys(value, expected, label):
    require(type(value) is dict and set(value) == set(expected),
            f"{label}: expected exactly {sorted(expected)}")


def text(value, label):
    require(isinstance(value, str) and bool(value.strip()), f"{label}: nonempty text required")
    return value


def relative(value):
    text(value, "path")
    parts = value.split("/")
    require(not value.startswith("/") and "\\" not in value and
            all(p not in {"", ".", ".."} for p in parts), "unsafe relative path")
    require(str(PurePosixPath(value)) == value, "non-canonical relative path")
    return value


def no_symlinks(path):
    path = Path(path).absolute()
    for p in [path, *path.parents]:
        require(not p.is_symlink(), f"symlink forbidden: {p}")
    return path


def root_path(value, create=False):
    path = no_symlinks(value)
    require(path.resolve() == path, "root must be canonical")
    if create:
        path.mkdir(parents=True, exist_ok=True)
    require(path.is_dir(), f"directory missing: {path}")
    return path


def under(root, rel):
    return no_symlinks(root / relative(rel))


def open_directory(path):
    """Anchor every path component; never follow a raced ancestor symlink."""
    path = Path(path).absolute()
    require(all(p not in {".", ".."} for p in path.parts), "non-canonical path")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    current = os.open(path.anchor, flags)
    try:
        for component in path.parts[1:]:
            child = os.open(component, flags, dir_fd=current)
            os.close(current)
            current = child
        return current
    except BaseException:
        os.close(current)
        raise


def read_regular_fd(fd, label):
    with os.fdopen(fd, "rb") as handle:
        info = os.fstat(handle.fileno())
        require(stat.S_ISREG(info.st_mode), f"regular file required: {label}")
        require(info.st_size <= MAX_FILE_BYTES, f"file exceeds {MAX_FILE_BYTES} bytes")
        data = handle.read(MAX_FILE_BYTES + 1)
    require(len(data) <= MAX_FILE_BYTES, "file grew beyond limit")
    return data


def read_bytes(path):
    path = no_symlinks(path)
    parent = open_directory(path.parent)
    try:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        return read_regular_fd(fd, str(path))
    finally:
        os.close(parent)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def load_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"duplicate JSON key: {key}")
            result[key] = value
        return result
    return json.loads(read_bytes(path).decode("utf-8"), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(HarnessError("non-finite JSON")))


def write_new(path, value):
    no_symlinks(path.parent)
    with path.open("xb") as handle:
        handle.write(encoded(value) + b"\n")


def evaluator_digest():
    return digest(encoded(bundle_digests(CONTROLLER_ROOT)))


def bundle_digests(root):
    return {name: digest(read_bytes(root / name)) for name in BUNDLE_FILES}


def run_knowledge(wiki, manifest, source_bytes):
    path = CONTROLLER_ROOT / "knowledge.py"
    module = ModuleType("protected_harness_knowledge")
    module.__file__ = str(path)
    # Execute the protected, hash-pinned source bytes, never a timestamp-valid pyc.
    exec(compile(read_bytes(path), str(path), "exec"), module.__dict__)
    diagnostics = module.lint_knowledge(wiki, manifest, source_bytes)
    require(type(diagnostics) is list and all(isinstance(d, str) for d in diagnostics), "invalid knowledge evaluator response")
    return {"id": "knowledge-lint", "status": "fail" if diagnostics else "pass", "messages": diagnostics}


def task_config(project, task_id):
    path = under(project, f"tasks/{identifier(task_id)}.json")
    data = load_json(path)
    validate_task(data, task_id)
    return data, digest(read_bytes(path))


def validate_task(data, task_id):
    keys(data, {"schema_version", "task_id", "profile", "goal", "required_files", "review_criteria", "modules", "limits"}, "task")
    require(type(data["schema_version"]) is int and data["schema_version"] == 2, "unsupported task version")
    require(data["task_id"] == task_id, "task ID mismatch")
    require(data["profile"] == "text-v2", "unsupported profile; implement and test a domain evaluator first")
    require(type(data["modules"]) is list and data["modules"] in ([], ["sources"], ["sources", "knowledge"]), "unsupported module selection; knowledge requires sources")
    keys(data["limits"], {"max_evaluations"}, "limits")
    cap = data["limits"]["max_evaluations"]
    require(type(cap) is int and cap > 0, "max_evaluations must be a positive integer")
    text(data["goal"], "goal")
    require(type(data["required_files"]) is list and data["required_files"], "required checks cannot be empty")
    files = set()
    for entry in data["required_files"]:
        keys(entry, {"path", "headings", "require_citations"}, "required file")
        rel = relative(entry["path"])
        require(rel not in files, "duplicate required file")
        files.add(rel)
        require(type(entry["headings"]) is list, "headings must be a list")
        for heading in entry["headings"]:
            text(heading, "heading")
            require("\n" not in heading and "\r" not in heading, "heading must be one literal line")
        require(type(entry["require_citations"]) is bool, "require_citations must be boolean")
        require(not entry["require_citations"] or "sources" in data["modules"], "citations require sources module")
    criteria = data["review_criteria"]
    require(type(criteria) is list and criteria, "review criteria cannot be empty")
    for criterion in criteria:
        identifier(criterion)
    require(len(set(criteria)) == len(criteria), "duplicate review criterion")


def manifest_config(project):
    path = under(project, "raw/manifest.json")
    data = load_json(path)
    keys(data, {"sources"}, "source manifest")
    require(type(data["sources"]) is list and data["sources"], "sources cannot be empty")
    ids, paths = set(), set()
    for entry in data["sources"]:
        keys(entry, {"id", "path", "sha256"}, "source")
        sid = identifier(entry["id"])
        rel = relative(entry["path"])
        require(rel != "manifest.json", "manifest cannot list itself")
        require(sid not in ids and rel not in paths, "duplicate source ID or path")
        ids.add(sid); paths.add(rel)
        require(isinstance(entry["sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]), "invalid SHA-256")
        require(digest(read_bytes(under(project / "raw", rel))) == entry["sha256"], f"source digest mismatch: {sid}")
    # All regular source files must be registered; hidden files count too.
    actual = {p for p, _ in files_in(project / "raw") if p != "manifest.json"}
    require(actual == paths, "unlisted or missing source file")
    return data, digest(read_bytes(path))


def files_in(root):
    root = root_path(root)
    found = []
    total = 0
    entries = 0
    def visit(directory_fd, prefix="", depth=0):
        nonlocal total, entries
        require(depth <= 64, "directory nesting limit exceeded")
        with os.scandir(directory_fd) as listing:
            for entry in listing:
                entries += 1
                require(entries <= MAX_ENTRIES, "too many directory entries")
                rel = relative(prefix + entry.name)
                info = entry.stat(follow_symlinks=False)
                require(not stat.S_ISLNK(info.st_mode), f"symlink forbidden: {rel}")
                if stat.S_ISDIR(info.st_mode):
                    child = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory_fd)
                    try:
                        visit(child, rel + "/", depth + 1)
                    finally:
                        os.close(child)
                else:
                    require(stat.S_ISREG(info.st_mode), f"regular file required: {rel}")
                    child = os.open(entry.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
                    data = read_regular_fd(child, rel)
                    total += len(data)
                    require(total <= MAX_TOTAL_BYTES, "file tree exceeds total size limit")
                    found.append((rel, data))
                    require(len(found) <= MAX_FILES, "too many files")
    descriptor = open_directory(root)
    try:
        visit(descriptor)
    finally:
        os.close(descriptor)
    return sorted(found)


def tree_digest(root):
    return digest(encoded({rel: digest(data) for rel, data in files_in(root)}))


def copy_snapshot(source, destination):
    destination.mkdir()
    for rel, data in files_in(source):
        target = destination / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as handle:
            handle.write(data)


def paths(project, state):
    project = root_path(project) if project is not None else None
    state = no_symlinks(state)
    require(state.resolve() == state, "state root must be canonical")
    controller = root_path(CONTROLLER_ROOT)
    def disjoint(a, b):
        return a != b and a not in b.parents and b not in a.parents
    if project is not None:
        require(disjoint(project, state), "state and project must be disjoint, not nested")
        require(disjoint(project, controller), "controller must be installed outside the project")
    require(disjoint(controller, state), "controller and state must be disjoint")
    return project, state


@contextmanager
def state_lock(project, state, create=True):
    project, state = paths(project, state)
    state = root_path(state, create=create)
    lock = no_symlinks(state / ".controller.lock")
    fd = os.open(lock, os.O_RDWR | os.O_NOFOLLOW | (os.O_CREAT if create else 0), 0o600)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), "controller lock must be a regular file")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for name in ("registrations", "runs", "releases", "publications"):
            root_path(state / name, create=create)
        yield project, state
    except BlockingIOError as exc:
        raise HarnessError("trusted state is busy; retry later") from exc
    finally:
        os.close(fd)


def build_pin(project, task_id):
    task, contract_hash = task_config(project, task_id)
    manifest, manifest_hash = manifest_config(project) if "sources" in task["modules"] else (None, None)
    return {"schema_version": 2, "project": str(project), "task": task, "manifest": manifest,
            "contract_sha256": contract_hash, "manifest_sha256": manifest_hash,
            "evaluator_sha256": evaluator_digest(), "controller_bundle": bundle_digests(CONTROLLER_ROOT),
            "rubric_sha256": digest(read_bytes(under(project, "qa/playbook.md")))}


def registration(project, state, task_id):
    record = load_json(under(state, f"registrations/{identifier(task_id)}.json"))
    current = build_pin(project, task_id)
    labels = {"contract_sha256": "task", "manifest_sha256": "manifest",
              "evaluator_sha256": "evaluator", "rubric_sha256": "rubric"}
    for field in PIN_FIELDS:
        require(record[field] == current[field], f"{labels[field]} changed; register a new task version")
    require(record == current, "registered project or pinned data mismatch")
    return record


def register(project, state, task):
    pin = build_pin(project, task)
    write_new(under(state, f"registrations/{identifier(task)}.json"), pin)
    return {"status": "registered", "task_id": task, "contract_sha256": pin["contract_sha256"]}


def structural_checks(inputs, snapshot, pin):
    actual = {rel for rel, _ in files_in(snapshot)}
    expected = {r["path"] for r in pin["task"]["required_files"]}
    checks = [{"id": "artifact-set", "status": "pass" if actual == expected else "fail",
               "messages": [] if actual == expected else ["artifact files differ from the contract"]}]
    sources = {s["id"]: s for s in pin["manifest"]["sources"]} if pin["manifest"] else {}
    for rule in pin["task"]["required_files"]:
        check = {"id": rule["path"], "status": "pass", "messages": []}
        try:
            content = read_bytes(under(snapshot, rule["path"])).decode("utf-8")
            require(bool(content.strip()), "required artifact is empty")
            for heading in rule["headings"]:
                require(heading in content.splitlines(), f"required literal heading absent: {heading}")
            citations = list(CITATION.finditer(content))
            require(not rule["require_citations"] or citations, "no valid citation syntax found")
            require(content.count("[[") == len(citations) == content.count("]]"), "malformed citation marker")
            require(not citations or "sources" in pin["task"]["modules"], "citations require sources module")
            for citation in citations:
                sid, start, end = citation.groups()
                require(sid in sources, f"unknown source: {sid}")
                source_text = read_bytes(under(inputs / "raw", sources[sid]["path"])).decode("utf-8")
                require(1 <= int(start) <= int(end) <= len(source_text.splitlines()), f"invalid source locator: {citation.group()}")
        except (HarnessError, FileNotFoundError, UnicodeError) as exc:
            check["status"] = "fail"; check["messages"].append(str(exc))
        checks.append(check)
    return checks


def source_bytes(inputs, pin):
    return {s["id"]: read_bytes(under(inputs / "raw", s["path"])) for s in pin["manifest"]["sources"]}


def frozen_inputs(inputs, pin):
    task = load_json(inputs / "task.json")
    validate_task(task, pin["task"]["task_id"])
    require(task == pin["task"] and digest(read_bytes(inputs / "task.json")) == pin["contract_sha256"], "frozen task mismatch")
    require(digest(read_bytes(inputs / "rubric.md")) == pin["rubric_sha256"], "frozen rubric mismatch")
    bundle = bundle_digests(inputs / "controller")
    require(bundle == pin["controller_bundle"] and digest(encoded(bundle)) == pin["evaluator_sha256"], "frozen controller bundle mismatch")
    require({p for p, _ in files_in(inputs / "controller")} == set(BUNDLE_FILES), "unexpected controller files")
    if "sources" in task["modules"]:
        manifest, manifest_hash = manifest_config(inputs)
        require(manifest == pin["manifest"] and manifest_hash == pin["manifest_sha256"], "frozen manifest mismatch")
    else:
        require(pin["manifest"] is None and pin["manifest_sha256"] is None and not (inputs / "raw").exists(), "unexpected source state")
    if "knowledge" in task["modules"]:
        knowledge_hash = tree_digest(inputs / "wiki")
    else:
        require(not (inputs / "wiki").exists(), "unexpected knowledge state")
        knowledge_hash = None
    return knowledge_hash


def admission_count(state, task):
    count = 0
    for path in (state / "runs").iterdir():
        require(not path.is_symlink(), "symlink in trusted run history")
        if path.is_dir():
            require((path / "admission.json").is_file(), "incomplete admission history; trusted recovery required")
            data = load_json(path / "admission.json")
            keys(data, {"run_id", "task_id", "candidate_id", "ordinal", "created_utc"}, "admission")
            require(data["run_id"] == path.name and type(data["task_id"]) is str, "invalid admission history")
            require(type(data["ordinal"]) is int and data["ordinal"] > 0, "invalid admission ordinal")
            count += data["task_id"] == task
    return count


def evaluate(project, state, task, candidate, run):
    run = identifier(run); candidate = identifier(candidate); task = identifier(task)
    run_dir = under(state, f"runs/{run}")
    require(not run_dir.exists(), "run ID already exists")
    pin = registration(project, state, task)
    candidate_path = root_path(under(project, f"results/candidates/{candidate}/artifacts"))
    if "knowledge" in pin["task"]["modules"]:
        root_path(under(project, "wiki"))
    used = admission_count(state, task)
    require(used < pin["task"]["limits"]["max_evaluations"], "evaluation limit reached")
    run_dir.mkdir()
    admission = {"run_id": run, "task_id": task, "candidate_id": candidate,
                 "ordinal": used + 1, "created_utc": datetime.now(timezone.utc).isoformat()}
    write_new(run_dir / "admission.json", admission)
    receipt = {"schema_version": 2, **admission, "status": "error", "candidate_sha256": None,
               "registration_sha256": None, "inputs_sha256": None, "knowledge_sha256": None,
               "checks": [], **{field: pin[field] for field in PIN_FIELDS}}
    try:
        copy_snapshot(candidate_path, run_dir / "snapshot")
        receipt["candidate_sha256"] = tree_digest(run_dir / "snapshot")
        inputs = run_dir / "inputs"; inputs.mkdir()
        for name, origin in (("task.json", project / f"tasks/{task}.json"), ("rubric.md", project / "qa/playbook.md")):
            (inputs / name).write_bytes(read_bytes(origin))
        (inputs / "controller").mkdir()
        for name in BUNDLE_FILES:
            (inputs / "controller" / name).write_bytes(read_bytes(CONTROLLER_ROOT / name))
        if "sources" in pin["task"]["modules"]:
            copy_snapshot(project / "raw", inputs / "raw")
        if "knowledge" in pin["task"]["modules"]:
            copy_snapshot(project / "wiki", inputs / "wiki")
        receipt["knowledge_sha256"] = frozen_inputs(inputs, pin)
        receipt["inputs_sha256"] = tree_digest(inputs)
        write_new(run_dir / "registration.json", pin)
        receipt["registration_sha256"] = digest(read_bytes(run_dir / "registration.json"))
        receipt["checks"] = structural_checks(inputs, run_dir / "snapshot", pin)
        if "knowledge" in pin["task"]["modules"]:
            receipt["checks"].append(run_knowledge(inputs / "wiki", pin["manifest"], source_bytes(inputs, pin)))
        registration(project, state, task)
        require(tree_digest(inputs) == receipt["inputs_sha256"], "frozen inputs changed while grading")
        require(tree_digest(run_dir / "snapshot") == receipt["candidate_sha256"], "snapshot changed while grading")
        receipt["status"] = "pass" if all(c["status"] == "pass" for c in receipt["checks"]) else "fail"
    except (HarnessError, OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        receipt["error"] = str(exc)
    write_new(run_dir / "receipt.json", receipt)
    return receipt


def frozen_run(state, run):
    run_dir = under(state, f"runs/{identifier(run)}")
    receipt = load_json(run_dir / "receipt.json")
    require(receipt["schema_version"] == 2 and receipt["run_id"] == run, "invalid run receipt")
    require(receipt["status"] == "pass" and receipt["checks"] and all(c["status"] == "pass" for c in receipt["checks"]), "hard checks did not pass")
    pin = load_json(run_dir / "registration.json")
    require(digest(read_bytes(run_dir / "registration.json")) == receipt["registration_sha256"], "historical registration changed")
    require(digest(read_bytes(under(state, f"registrations/{receipt['task_id']}.json"))) == receipt["registration_sha256"], "trusted registration history changed")
    admission = load_json(run_dir / "admission.json")
    keys(admission, {"run_id", "task_id", "candidate_id", "ordinal", "created_utc"}, "admission")
    require(all(receipt[field] == value for field, value in admission.items()), "admission and receipt disagree")
    for field in PIN_FIELDS:
        require(receipt[field] == pin[field], f"receipt {field} mismatch")
    require(receipt["candidate_sha256"] == tree_digest(run_dir / "snapshot"), "snapshot changed after evaluation")
    require(receipt["inputs_sha256"] == tree_digest(run_dir / "inputs"), "frozen inputs changed after evaluation")
    require(receipt["knowledge_sha256"] == frozen_inputs(run_dir / "inputs", pin), "knowledge snapshot mismatch")
    return run_dir, receipt, pin


def checked_run(project, state, run):
    run_dir, receipt, pin = frozen_run(state, run)
    require(registration(project, state, receipt["task_id"]) == pin, "current registration mismatch")
    return run_dir, receipt, pin


def validate_review(data, receipt, task):
    keys(data, {"run_id", "candidate_sha256", "contract_sha256", "reviewer", "criteria"}, "review")
    for field in ("run_id", "candidate_sha256", "contract_sha256"):
        require(data[field] == receipt[field], f"review {field} mismatch")
    text(data["reviewer"], "reviewer")
    require(type(data["criteria"]) is list, "criteria must be a list")
    ids = []
    for entry in data["criteria"]:
        keys(entry, {"id", "status", "evidence"}, "review criterion")
        ids.append(identifier(entry["id"]))
        require(entry["status"] in ("pass", "fail", "unknown"), "invalid review status")
        text(entry["evidence"], "review evidence")
    require(len(ids) == len(set(ids)) and set(ids) == set(task["review_criteria"]), "missing, extra or duplicate review criteria")
    return all(c["status"] == "pass" for c in data["criteria"])


def review(project, state, run, file):
    run_dir, receipt, pin = checked_run(project, state, run)
    data = load_json(Path(file))
    accepted = validate_review(data, receipt, pin["task"])
    write_new(run_dir / "review.json", {"accepted": accepted, "review": data})
    return {"run_id": run, "status": "review_pass" if accepted else "review_rejected"}


def accepted_review(run_dir, receipt, pin):
    reviewed = load_json(run_dir / "review.json")
    keys(reviewed, {"accepted", "review"}, "stored review")
    require(reviewed["accepted"] is True and validate_review(reviewed["review"], receipt, pin["task"]), "review did not pass")
    return reviewed


def promote(project, state, run, release):
    release = identifier(release)
    run_dir, receipt, pin = checked_run(project, state, run)
    accepted_review(run_dir, receipt, pin)
    destination = under(state, f"releases/{release}")
    publication_path = under(state, f"publications/{release}.json")
    require(not destination.exists() and not publication_path.exists(), "release ID already exists")
    stage = Path(tempfile.mkdtemp(prefix=".staging-", dir=state / "releases"))
    try:
        copy_snapshot(run_dir / "snapshot", stage / "artifacts")
        copy_snapshot(run_dir / "inputs", stage / "inputs")
        history = {}
        for name in ("registration.json", "receipt.json", "review.json", "admission.json"):
            content = read_bytes(run_dir / name)
            (stage / name).write_bytes(content)
            history[name] = digest(content)
        require(tree_digest(stage / "artifacts") == receipt["candidate_sha256"], "release copy digest mismatch")
        require(tree_digest(stage / "inputs") == receipt["inputs_sha256"], "release input copy mismatch")
        write_new(stage / "release.json", {"schema_version": 2, "release_id": release, "run_id": run,
                                           "candidate_sha256": receipt["candidate_sha256"], "knowledge_sha256": receipt["knowledge_sha256"]})
        # Separate protected publication record binds all release bytes and history.
        # A crash before rename leaves an incomplete publication, which cannot verify.
        publication = {"schema_version": 2, "release_id": release, "run_id": run,
                       "release_sha256": tree_digest(stage), "history": history}
        write_new(publication_path, publication)
        os.rename(stage, destination)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    return {"status": "promoted", "release_id": release, "path": str(destination),
            "candidate_sha256": receipt["candidate_sha256"]}


def verify_release(state, release):
    release = identifier(release)
    destination = under(state, f"releases/{release}")
    publication = load_json(under(state, f"publications/{release}.json"))
    require(publication["schema_version"] == 2 and publication["release_id"] == release, "invalid publication record")
    require(tree_digest(destination) == publication["release_sha256"], "release bytes changed")
    run_dir, receipt, pin = frozen_run(state, publication["run_id"])
    reviewed = accepted_review(run_dir, receipt, pin)
    for name, expected in publication["history"].items():
        require(name in {"registration.json", "receipt.json", "review.json", "admission.json"}, "unexpected history entry")
        require(digest(read_bytes(run_dir / name)) == expected == digest(read_bytes(destination / name)), "release or history binding changed")
    require(set(publication["history"]) == {"registration.json", "receipt.json", "review.json", "admission.json"}, "incomplete history binding")
    release_info = load_json(destination / "release.json")
    require(release_info["run_id"] == publication["run_id"] and release_info["release_id"] == release, "release identity mismatch")
    require(tree_digest(destination / "artifacts") == receipt["candidate_sha256"], "release artifact mismatch")
    require(tree_digest(destination / "inputs") == receipt["inputs_sha256"], "release input mismatch")
    require(frozen_inputs(destination / "inputs", pin) == receipt["knowledge_sha256"], "release knowledge mismatch")
    return {"status": "verified", "release_id": release, "run_id": receipt["run_id"],
            "candidate_sha256": receipt["candidate_sha256"], "knowledge_sha256": receipt["knowledge_sha256"],
            "meaning": "Frozen bytes and recorded historical acceptance verified; current suitability, semantic truth, and identity authentication are not established."}


def doctor(project, state, task):
    project, state = paths(project, state)
    pin = build_pin(project, identifier(task))
    registered = (state / f"registrations/{task}.json").is_file()
    if registered:
        registration(project, state, task)
    return {"status": "ready", "task_id": task, "registered": registered,
            "modules": pin["task"]["modules"], "max_evaluations": pin["task"]["limits"]["max_evaluations"],
            "meaning": "Non-mutating schema/runtime/path preflight only; does not establish deployment isolation."}


def execute(command, project=None, state=None, **kwargs):
    require(state is not None, "state path is required")
    if command == "doctor":
        require(project is not None, "project path is required")
        return doctor(project, state, **kwargs)
    if command == "verify-release":
        with state_lock(None, state, create=False) as (_, state_root):
            return verify_release(state_root, **kwargs)
    functions = {"register": register, "evaluate": evaluate, "review": review, "promote": promote}
    require(command in functions, "unknown command")
    require(project is not None, "project path is required")
    with state_lock(project, state) as (project_root, state_root):
        return functions[command](project_root, state_root, **kwargs)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", help="Required except for verify-release")
    parser.add_argument("--state", required=True, help="Trusted disjoint state directory")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("register", "doctor"):
        sub.add_parser(name).add_argument("--task", required=True)
    ev = sub.add_parser("evaluate")
    for flag in ("task", "candidate", "run"):
        ev.add_argument(f"--{flag}", required=True)
    rv = sub.add_parser("review")
    rv.add_argument("--run", required=True); rv.add_argument("--file", required=True)
    pr = sub.add_parser("promote")
    pr.add_argument("--run", required=True); pr.add_argument("--release", required=True)
    sub.add_parser("verify-release").add_argument("--release", required=True)
    args = vars(parser.parse_args(argv))
    try:
        result = execute(**args)
        print(json.dumps(result, indent=2))
        return 0 if result["status"] not in {"fail", "error", "review_rejected"} else 1
    except (HarnessError, OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
