#!/usr/bin/env python3
"""Bounded propose -> evaluate -> keep/discard loop (Python 3.10+, POSIX).

Commands are trusted integrations, not sandboxed code. The proposer supplies text
patches through JSON; only the controller applies them. Evaluate in an OS sandbox
when candidate code is untrusted. This module does not establish semantic truth,
authenticate evaluators, cap billing, or confer release-controller acceptance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import stat
import subprocess
import sys
import time

MAX_FILE = 10 * 1024 * 1024
MAX_TREE = 50 * 1024 * 1024
MAX_FILES = 1000
MAX_OUTPUT = 2 * 1024 * 1024
CONFIG_KEYS = {"schema_version", "goal", "baseline", "mutable_files", "proposer",
               "evaluator", "evaluator_inputs", "direction", "min_delta",
               "max_experiments", "command_timeout_seconds", "total_timeout_seconds"}


class HarnessError(Exception):
    pass


class CommandFailure(HarnessError):
    def __init__(self, status, detail):
        super().__init__(detail)
        self.status = status


def digest(data):
    return hashlib.sha256(data).hexdigest()


def strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise HarnessError(f"duplicate JSON key: {key}")
            result[key] = value
        return result
    try:
        return json.loads(text, object_pairs_hook=pairs,
                          parse_constant=lambda x: (_ for _ in ()).throw(HarnessError(f"invalid JSON number: {x}")))
    except (ValueError, UnicodeError) as exc:
        raise HarnessError(f"invalid JSON: {exc}") from exc


def save_json(path, document):
    data = json.dumps(document, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
    temp = path.with_name(path.name + ".tmp")
    with temp.open("x", encoding="utf-8") as stream:
        stream.write(data)
    os.replace(temp, path)


def safe_relative(value):
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise HarnessError("invalid relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or value != path.as_posix() or any(p in {".", ".."} for p in path.parts):
        raise HarnessError(f"unsafe relative path: {value!r}")
    if len(path.parts) > 64:
        raise HarnessError("path too deep")
    return value


def tree(root):
    if root.is_symlink() or not root.is_dir():
        raise HarnessError(f"not a regular directory: {root}")
    result = {}
    total = entries = 0
    for directory, dirs, files in os.walk(root, followlinks=False):
        parent = Path(directory)
        if len(parent.relative_to(root).parts) > 64:
            raise HarnessError("tree too deep")
        for name in dirs + files:
            entries += 1
            path = parent / name
            mode = path.lstat().st_mode
            if entries > 5000 or stat.S_ISLNK(mode):
                raise HarnessError("symlink or too many tree entries")
            if not stat.S_ISREG(mode) and not stat.S_ISDIR(mode):
                raise HarnessError("nonregular tree entry")
        for name in files:
            path = parent / name
            size = path.stat().st_size
            total += size
            if size > MAX_FILE or total > MAX_TREE or len(result) >= MAX_FILES:
                raise HarnessError("candidate exceeds size limits")
            result[path.relative_to(root).as_posix()] = digest(path.read_bytes())
    return dict(sorted(result.items()))


def tree_digest(root):
    return digest(json.dumps(tree(root), sort_keys=True).encode())


def within(path, directory):
    return path == directory or directory in path.parents


def numeric(value, name, *, positive=False):
    if not finite_number(value):
        raise HarnessError(f"{name} must be a finite number")
    if value < 0 or (positive and value <= 0):
        raise HarnessError(f"{name} outside allowed range")
    return value


def finite_number(value):
    try:
        return not isinstance(value, bool) and isinstance(value, (float, int)) and math.isfinite(value)
    except OverflowError:
        return False


def load_config(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_OUTPUT:
        raise HarnessError("configuration must be a bounded regular file")
    raw = path.read_bytes()
    config = strict_json(raw)
    if not isinstance(config, dict) or set(config) != CONFIG_KEYS:
        raise HarnessError("configuration keys do not match schema")
    if type(config["schema_version"]) is not int or config["schema_version"] != 1:
        raise HarnessError("unsupported experiment schema")
    if not isinstance(config["goal"], str) or not config["goal"].strip():
        raise HarnessError("goal must be nonempty")
    config["goal"].encode("utf-8")
    base = path.parent
    if not isinstance(config["baseline"], str) or not config["baseline"]:
        raise HarnessError("baseline must name a directory")
    baseline_input = base / config["baseline"]
    if baseline_input.is_symlink():
        raise HarnessError("baseline may not be a symlink")
    config["baseline"] = str(baseline_input.resolve())
    mutable = config["mutable_files"]
    if not isinstance(mutable, list) or not mutable or len(mutable) > MAX_FILES:
        raise HarnessError("mutable_files must be a nonempty bounded list")
    for name in mutable:
        safe_relative(name)
    if len(set(mutable)) != len(mutable):
        raise HarnessError("duplicate mutable file")
    if any(a != b and b.startswith(a + "/") for a in mutable for b in mutable):
        raise HarnessError("mutable paths overlap")
    pins = {}
    for key in ("proposer", "evaluator"):
        argv = config[key]
        if not isinstance(argv, list) or not argv or any(not isinstance(a, str) or not a or "\x00" in a for a in argv):
            raise HarnessError(f"{key} must be a nonempty argv list")
        executable = shutil.which(argv[0]) if "/" not in argv[0] else str(base / argv[0])
        if not executable or not Path(executable).is_file():
            raise HarnessError(f"{key} executable not found")
        argv[0] = str(Path(executable).resolve())
        for i, arg in enumerate(argv):
            possible = base / arg
            if possible.is_file():
                argv[i] = str(possible.resolve())
                pins[argv[i]] = digest(possible.read_bytes())
    inputs = config["evaluator_inputs"]
    if not isinstance(inputs, list) or not inputs:
        raise HarnessError("evaluator_inputs must list the evaluator and fixed input files")
    resolved = []
    for name in inputs:
        if not isinstance(name, str) or not name:
            raise HarnessError("invalid evaluator input")
        entry = base / name
        if entry.is_symlink() or not entry.is_file():
            raise HarnessError("evaluator inputs must be regular files")
        entry = entry.resolve()
        resolved.append(str(entry))
        pins[str(entry)] = digest(entry.read_bytes())
    if len(set(resolved)) != len(resolved):
        raise HarnessError("duplicate evaluator input")
    config["evaluator_inputs"] = resolved
    if not isinstance(config["direction"], str) or config["direction"] not in {"min", "max"}:
        raise HarnessError("direction must be min or max")
    numeric(config["min_delta"], "min_delta")
    if type(config["max_experiments"]) is not int or not 1 <= config["max_experiments"] <= 1000:
        raise HarnessError("max_experiments must be an integer from 1 to 1000")
    numeric(config["command_timeout_seconds"], "command_timeout_seconds", positive=True)
    numeric(config["total_timeout_seconds"], "total_timeout_seconds", positive=True)
    pins[str(path)] = digest(raw)
    pins[str(Path(__file__).resolve())] = digest(Path(__file__).read_bytes())
    return config, pins


def check_pins(pins):
    for name, expected in pins.items():
        path = Path(name)
        if path.is_symlink() or not path.is_file() or digest(path.read_bytes()) != expected:
            raise HarnessError(f"fixed input changed: {name}")


def kill_group(process):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def command(argv, cwd, payload, timeout, log_prefix, candidate=None):
    if timeout <= 0:
        raise CommandFailure("timeout", "overall time budget exhausted")
    env = os.environ.copy()
    # Prevent Python evaluators from creating __pycache__ in captured candidates.
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if candidate is not None:
        env["HARNESS_CANDIDATE"] = str(candidate)
    start = time.monotonic()
    input_path = log_prefix.with_suffix(".stdin.json")
    input_path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    output_path = log_prefix.with_suffix(".stdout")
    error_path = log_prefix.with_suffix(".stderr")
    process = None
    status = None
    try:
        with input_path.open("rb") as stdin, output_path.open("wb") as stdout, error_path.open("wb") as stderr:
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=stdin, stdout=stdout,
                                       stderr=stderr, start_new_session=True, shell=False)
            while process.poll() is None:
                if time.monotonic() - start >= timeout:
                    status = "timeout"
                    break
                if output_path.stat().st_size + error_path.stat().st_size > MAX_OUTPUT:
                    status = "output_limit"
                    break
                time.sleep(0.02)
            if status:
                kill_group(process)
            process.wait()
    except OSError as exc:
        raise CommandFailure("crash", str(exc)) from exc
    finally:
        if process is not None:
            kill_group(process)  # also stop orphaned descendants after a normal exit
            process.wait()
    if status:
        raise CommandFailure(status, f"command {status}; see {log_prefix.name} logs")
    if output_path.stat().st_size + error_path.stat().st_size > MAX_OUTPUT:
        raise CommandFailure("output_limit", "command output exceeds bound")
    if process.returncode != 0:
        tail = error_path.read_bytes()[-4000:].decode("utf-8", errors="replace")
        raise CommandFailure("crash", f"command exited {process.returncode}: {tail}")
    try:
        return strict_json(output_path.read_bytes())
    except HarnessError as exc:
        raise CommandFailure("malformed", str(exc)) from exc


def validate_proposal(document, mutable):
    if not isinstance(document, dict) or set(document) != {"hypothesis", "files"}:
        raise HarnessError("proposal must contain exactly hypothesis and files")
    if not isinstance(document["hypothesis"], str) or not document["hypothesis"].strip():
        raise HarnessError("proposal needs a hypothesis")
    document["hypothesis"].encode("utf-8")
    files = document["files"]
    if not isinstance(files, dict) or not files:
        raise HarnessError("proposal needs at least one changed file")
    total = 0
    for name, content in files.items():
        safe_relative(name)
        if name not in mutable:
            raise HarnessError(f"proposal outside mutable scope: {name}")
        if not isinstance(content, str):
            raise HarnessError("proposed file contents must be strings")
        size = len(content.encode("utf-8"))
        total += size
        if size > MAX_FILE or total > MAX_TREE:
            raise HarnessError("proposed files exceed size limits")
    return document


def apply_proposal(directory, proposal):
    for name, content in proposal["files"].items():
        path = directory / name
        for parent in path.parents:
            if parent == directory:
                break
            if parent.exists() and (parent.is_symlink() or not parent.is_dir()):
                raise HarnessError("invalid proposal parent")
        if path.exists() and (path.is_symlink() or not path.is_file()):
            raise HarnessError("invalid proposal destination")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def metric_result(document):
    if not isinstance(document, dict) or set(document) != {"valid", "metric"} or type(document["valid"]) is not bool:
        raise CommandFailure("malformed", "evaluator must emit exactly valid:boolean and metric:number")
    if not document["valid"]:
        raise CommandFailure("invalid", "evaluator marked candidate invalid")
    try:
        value = document["metric"]
        if not finite_number(value):
            raise HarnessError("metric must be finite and numeric")
    except HarnessError as exc:
        raise CommandFailure("malformed", str(exc)) from exc
    return value


def _run(config_path, state):
    config_path = Path(config_path).absolute()
    state = Path(state).absolute()
    if os.name != "posix":
        raise HarnessError("this reference requires POSIX process groups")
    if state.exists() or state.is_symlink():
        raise HarnessError("state must be a new directory; resuming is not supported")
    config, pins = load_config(config_path)
    baseline = Path(config["baseline"])
    state = state.resolve()
    if within(state, baseline) or within(baseline, state):
        raise HarnessError("state and baseline must be disjoint")
    for name in pins:
        if within(Path(name), baseline) or within(Path(name), state):
            raise HarnessError("fixed inputs and executables must be outside baseline and state")
    baseline_hash = tree_digest(baseline)
    for name in config["mutable_files"]:
        path = baseline / name
        if path.exists():
            if not path.is_file():
                raise HarnessError("mutable path must name a file")
            path.read_text(encoding="utf-8")
    # Atomic mkdir admits one runner; existing or interrupted state is never reused.
    state.mkdir(parents=True, exist_ok=False)
    (state / "candidates").mkdir()
    (state / "logs").mkdir()
    (state / "worker").mkdir()
    started = time.monotonic()
    deadline = started + config["total_timeout_seconds"]
    history = []
    best = None
    best_hash = None
    best_metric = None
    baseline_metric = None
    best_iteration = None
    fixed = {"config": config, "pins": pins, "baseline_sha256": baseline_hash}
    save_json(state / "contract.json", fixed)
    contract_hash = digest((state / "contract.json").read_bytes())

    def event(kind, **fields):
        entry = {"event": kind, "elapsed_seconds": round(time.monotonic() - started, 6), **fields}
        with (state / "events.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + "\n")
            stream.flush()
        return entry

    def intact():
        check_pins(pins)
        if tree_digest(baseline) != baseline_hash:
            raise HarnessError("baseline input changed")
        if digest((state / "contract.json").read_bytes()) != contract_hash:
            raise HarnessError("captured experiment contract changed")
        if best is not None and tree_digest(best) != best_hash:
            raise HarnessError("best snapshot changed")

    def invoke(argv, cwd, payload, name, candidate=None):
        intact()
        try:
            return command(argv, cwd, payload,
                           min(config["command_timeout_seconds"], deadline - time.monotonic()),
                           state / "logs" / name, candidate)
        finally:
            intact()

    def evaluate(candidate, iteration):
        before = tree_digest(candidate)
        event("evaluation_started", iteration=iteration, candidate_sha256=before)
        try:
            data = invoke(config["evaluator"], candidate, {"iteration": iteration},
                          f"{iteration:04d}-evaluate", candidate)
            value = metric_result(data)
        finally:
            if tree_digest(candidate) != before:
                raise HarnessError("evaluator modified its candidate")
        return value, before

    event("run_started", max_experiments=config["max_experiments"])
    completed = 0
    stop_reason = "experiment_limit"
    try:
        candidate = state / "candidates" / "0000"
        shutil.copytree(baseline, candidate)
        best_metric, best_hash = evaluate(candidate, 0)
        baseline_metric = best_metric
        best, best_iteration = candidate, 0
        save_json(state / "best.json", {"iteration": 0, "metric": best_metric,
                                        "path": str(best), "sha256": best_hash})
        event("baseline", metric=best_metric, status="keep")
        for iteration in range(1, config["max_experiments"] + 1):
            if time.monotonic() >= deadline:
                stop_reason = "time_limit"
                break
            event("experiment_started", iteration=iteration, best_metric=best_metric)
            status, reason, value, hypothesis, feedback = "discard", "unknown", None, None, None
            candidate = state / "candidates" / f"{iteration:04d}"
            try:
                context = {"schema_version": 1, "goal": config["goal"], "iteration": iteration,
                           "direction": config["direction"], "min_delta": config["min_delta"],
                           "best_metric": best_metric,
                           "files": {name: (best / name).read_text(encoding="utf-8") if (best / name).exists() else None
                                     for name in config["mutable_files"]},
                           "history": history[-20:]}
                document = invoke(config["proposer"], state / "worker", context,
                                  f"{iteration:04d}-propose")
                try:
                    proposal = validate_proposal(document, config["mutable_files"])
                except (HarnessError, UnicodeError) as exc:
                    raise CommandFailure("invalid_proposal", str(exc)) from exc
                hypothesis = proposal["hypothesis"]
                shutil.copytree(best, candidate)
                try:
                    apply_proposal(candidate, proposal)
                except (HarnessError, OSError) as exc:
                    raise CommandFailure("invalid_proposal", str(exc)) from exc
                if tree_digest(candidate) == best_hash:
                    reason = "no_change"
                else:
                    value, candidate_hash = evaluate(candidate, iteration)
                    improvement = (best_metric - value if config["direction"] == "min" else value - best_metric)
                    if improvement > config["min_delta"]:
                        best, best_hash, best_metric, best_iteration = candidate, candidate_hash, value, iteration
                        save_json(state / "best.json", {"iteration": iteration, "metric": value,
                                                        "path": str(best), "sha256": best_hash})
                        status, reason = "keep", "improved"
                    else:
                        reason = "not_improved"
            except CommandFailure as exc:
                reason = exc.status
                feedback = str(exc)
                event("command_failure", iteration=iteration, status=exc.status, detail=str(exc))
            completed += 1
            record = {"iteration": iteration, "status": status, "reason": reason,
                      "metric": value, "hypothesis": hypothesis, "best_metric": best_metric,
                      "feedback": feedback}
            history.append(record)
            event("experiment_completed", **record)
        intact()
        summary = {"status": "completed", "stop_reason": stop_reason,
                   "experiments_completed": completed, "baseline_metric": baseline_metric,
                   "best_metric": best_metric, "best_iteration": best_iteration,
                   "best_path": str(best), "best_sha256": best_hash,
                   "elapsed_seconds": round(time.monotonic() - started, 6)}
        save_json(state / "summary.json", summary)
        event("run_completed", **summary)
        return summary
    except (Exception, KeyboardInterrupt) as exc:
        event("run_failed", status="interrupted" if isinstance(exc, KeyboardInterrupt) else "error", detail=str(exc))
        save_json(state / "summary.json", {"status": "error", "detail": str(exc),
                                           "experiments_completed": completed,
                                           "best_path": str(best) if best else None})
        raise


def run(config_path, state):
    """Run on the main thread so SIGTERM can clean up child process groups."""
    def terminated(signum, frame):
        raise KeyboardInterrupt("terminated by SIGTERM")
    try:
        previous = signal.signal(signal.SIGTERM, terminated)
    except ValueError as exc:
        raise HarnessError("run must execute on the main thread for signal cleanup") from exc
    try:
        return _run(config_path, state)
    finally:
        signal.signal(signal.SIGTERM, previous)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    launch = commands.add_parser("run")
    launch.add_argument("--config", type=Path, required=True)
    launch.add_argument("--state", type=Path, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(run(args.config, args.state), ensure_ascii=False))
        return 0
    except (HarnessError, OSError, UnicodeError, KeyboardInterrupt) as exc:
        print(json.dumps({"status": "error", "detail": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
