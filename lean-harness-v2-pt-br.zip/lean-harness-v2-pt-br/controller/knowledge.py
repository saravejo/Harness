"""Optional structural knowledge checks against controller-captured, immutable inputs.

API: lint_knowledge(wiki_dir, manifest, source_bytes_by_id) -> list[str].
An empty list is a structural pass, never proof of truth, freshness or completeness.

claims.jsonl contains one exact-key object per nonblank line:
  {"id": "C1", "text": "...", "status": "supported", "sources": [
    {"id": "S1", "sha256": "...", "start_line": 1, "end_line": 2}],
   "supersedes": []}
Statuses: supported, assumption, disputed, superseded. Supported claims need at
least one source. All references use inclusive, one-based UTF-8 text line numbers.

Required files: index.md and claims.jsonl. Every Markdown page below topics/ or
sources/ must have a direct inline file link from index.md. Source summary pages
are optional; no one-summary-per-source or claim-coverage requirement exists.

Markdown checks cover simple inline links/images: [label](path), [label](<path>)
and an optional quoted title. Relative destinations must stay inside this wiki
snapshot and resolve to a regular file. Fragments are not anchor-validated.
http(s) and mailto destinations are not fetched. Reference-style definitions and
HTML links/images are rejected; nested Markdown link grammar is unsupported.
Code fences and inline code are skipped. This is a deliberately bounded format,
not a general Markdown implementation. Run only on a protected frozen snapshot;
the no-follow reads below are defense in depth, not authorization or isolation.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
from urllib.parse import unquote, urlsplit

MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_TREE_BYTES = 50 * 1024 * 1024
MAX_FILES = 1000
MAX_ENTRIES = 5000
MAX_DEPTH = 64
ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")
CLAIM_KEYS = {"id", "text", "status", "sources", "supersedes"}
REF_KEYS = {"id", "sha256", "start_line", "end_line"}
STATUSES = {"supported", "assumption", "disputed", "superseded"}


class KnowledgeError(ValueError):
    pass


def _object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise KnowledgeError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _exact(value, keys, label):
    if not isinstance(value, dict) or set(value) != keys:
        raise KnowledgeError(f"{label}: expected exact keys {', '.join(sorted(keys))}")


def _identifier(value):
    return isinstance(value, str) and ID.fullmatch(value) is not None


def _open_directory(path):
    absolute = Path(os.path.abspath(path))
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in absolute.parts[1:]:
            nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise


def _read_tree(path):
    """Read bounded regular files using descriptor-relative, no-follow traversal."""
    files, counts = {}, {"bytes": 0, "entries": 0}
    rootfd = _open_directory(path)

    def walk(fd, prefix, depth):
        if depth > MAX_DEPTH:
            raise KnowledgeError("wiki exceeds maximum directory depth")
        with os.scandir(fd) as iterator:
            names = sorted(entry.name for entry in iterator)
        counts["entries"] += len(names)
        if counts["entries"] > MAX_ENTRIES:
            raise KnowledgeError("wiki exceeds maximum entry count")
        for name in names:
            relative = f"{prefix}/{name}" if prefix else name
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                raise KnowledgeError(f"symlink forbidden: {relative}")
            if stat.S_ISDIR(info.st_mode):
                child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                try:
                    walk(child, relative, depth + 1)
                finally:
                    os.close(child)
            elif stat.S_ISREG(info.st_mode):
                child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
                try:
                    if not stat.S_ISREG(os.fstat(child).st_mode):
                        raise KnowledgeError(f"nonregular wiki entry: {relative}")
                    chunks, size = [], 0
                    while True:
                        chunk = os.read(child, min(65536, MAX_FILE_BYTES + 1 - size))
                        if not chunk:
                            break
                        chunks.append(chunk)
                        size += len(chunk)
                        if size > MAX_FILE_BYTES:
                            raise KnowledgeError(f"wiki file exceeds byte limit: {relative}")
                    files[relative] = b"".join(chunks)
                    counts["bytes"] += size
                    if len(files) > MAX_FILES or counts["bytes"] > MAX_TREE_BYTES:
                        raise KnowledgeError("wiki exceeds tree resource limits")
                finally:
                    os.close(child)
            else:
                raise KnowledgeError(f"nonregular wiki entry: {relative}")
    try:
        walk(rootfd, "", 0)
    finally:
        os.close(rootfd)
    return files


def _sources(manifest, source_bytes):
    _exact(manifest, {"sources"}, "manifest")
    if not isinstance(manifest["sources"], list) or not isinstance(source_bytes, dict):
        raise KnowledgeError("manifest sources must be a list and frozen sources a dictionary")
    result = {}
    for item in manifest["sources"]:
        _exact(item, {"id", "path", "sha256"}, "manifest source")
        sid = item["id"]
        if not _identifier(sid) or sid in result:
            raise KnowledgeError("manifest source ID invalid or duplicate")
        if not isinstance(item["path"], str) or not item["path"]:
            raise KnowledgeError(f"manifest source path invalid: {sid}")
        expected = item["sha256"]
        if not isinstance(expected, str) or not SHA.fullmatch(expected):
            raise KnowledgeError(f"manifest source hash invalid: {sid}")
        data = source_bytes.get(sid)
        if not isinstance(data, bytes):
            raise KnowledgeError(f"frozen source missing or not bytes: {sid}")
        if hashlib.sha256(data).hexdigest() != expected:
            raise KnowledgeError(f"frozen source hash mismatch: {sid}")
        try:
            lines = len(data.decode("utf-8").splitlines())
        except UnicodeDecodeError:
            lines = None  # Binary sources are allowed, but cannot have text locators.
        result[sid] = {"sha256": expected, "lines": lines}
    if set(source_bytes) != set(result):
        raise KnowledgeError("frozen source IDs do not match manifest")
    return result


def _claims(data, sources):
    diagnostics, claims = [], {}
    try:
        lines = data.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return ["claims.jsonl: invalid UTF-8"]
    for number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        label = f"claims.jsonl:{number}"
        try:
            obj = json.loads(line, object_pairs_hook=_object_pairs,
                             parse_constant=lambda value: (_ for _ in ()).throw(KnowledgeError(f"nonfinite JSON value: {value}")))
            _exact(obj, CLAIM_KEYS, label)
            cid = obj["id"]
            if not _identifier(cid):
                raise KnowledgeError("invalid claim ID")
            if cid in claims:
                raise KnowledgeError(f"duplicate claim ID: {cid}")
            if not isinstance(obj["text"], str) or not obj["text"].strip():
                raise KnowledgeError("claim text must be nonempty")
            if not isinstance(obj["status"], str) or obj["status"] not in STATUSES:
                raise KnowledgeError("invalid claim status")
            if not isinstance(obj["sources"], list):
                raise KnowledgeError("sources must be a list")
            if obj["status"] == "supported" and not obj["sources"]:
                raise KnowledgeError("supported claim requires a source")
            seen_refs = set()
            for ref in obj["sources"]:
                _exact(ref, REF_KEYS, "source reference")
                sid = ref["id"]
                if not _identifier(sid) or sid not in sources:
                    raise KnowledgeError("unknown source ID")
                if ref["sha256"] != sources[sid]["sha256"]:
                    raise KnowledgeError(f"source reference hash mismatch: {sid}")
                start, end, count = ref["start_line"], ref["end_line"], sources[sid]["lines"]
                if type(start) is not int or type(end) is not int or count is None or not (1 <= start <= end <= count):
                    raise KnowledgeError(f"invalid source locator: {sid}")
                signature = sid, start, end
                if signature in seen_refs:
                    raise KnowledgeError(f"duplicate source locator: {sid}")
                seen_refs.add(signature)
            supersedes = obj["supersedes"]
            if not isinstance(supersedes, list) or any(not _identifier(x) for x in supersedes):
                raise KnowledgeError("supersedes must be a list of claim IDs")
            if len(supersedes) != len(set(supersedes)):
                raise KnowledgeError("duplicate supersession target")
            claims[cid] = obj
        except (ValueError, TypeError, RecursionError) as exc:
            diagnostics.append(f"{label}: {exc}")
    for cid, obj in claims.items():
        for target in obj["supersedes"]:
            if target == cid:
                diagnostics.append(f"{cid}: self-supersession forbidden")
            elif target not in claims:
                diagnostics.append(f"{cid}: unknown supersession target {target}")
    # Iterative traversal avoids recursion failure for long, bounded claim lists.
    state = {}
    for start in claims:
        if state.get(start):
            continue
        stack = [(start, False)]
        while stack:
            current, leaving = stack.pop()
            if leaving:
                state[current] = 2
                continue
            if state.get(current) == 2:
                continue
            if state.get(current) == 1:
                diagnostics.append(f"supersession cycle includes {current}")
                continue
            state[current] = 1
            stack.append((current, True))
            for target in reversed(claims[current]["supersedes"]):
                if target in claims:
                    if state.get(target) == 1:
                        diagnostics.append(f"supersession cycle includes {target}")
                    elif state.get(target) != 2:
                        stack.append((target, False))
    return diagnostics


def _without_code(text):
    lines, fence = [], None
    for line in text.splitlines():
        match = re.match(r"^\s*(`{3,}|~{3,})", line)
        if match:
            marker = match.group(1)
            if fence is None:
                fence = (marker[0], len(marker))
            elif marker[0] == fence[0] and len(marker) >= fence[1]:
                fence = None
            lines.append("")
        elif fence:
            lines.append("")
        else:
            lines.append(re.sub(r"(`+)(.*?)\1", "", line))
    return "\n".join(lines)


def _destination(raw):
    # Optional title is accepted but never interpreted.
    match = re.fullmatch(r'\s*(?:<([^<>\n]+)>|([^\s<>]+))(?:\s+(?:"[^"\n]*"|\x27[^\x27\n]*\x27))?\s*', raw)
    if not match:
        raise KnowledgeError("unsupported inline link destination syntax")
    return match.group(1) or match.group(2)


def _local_target(page, destination):
    decoded = unquote(destination)
    parsed = urlsplit(decoded)
    if parsed.scheme:
        if parsed.scheme.lower() in {"http", "https", "mailto"}:
            return None
        raise KnowledgeError("unsupported URL scheme")
    if parsed.netloc or decoded.startswith("/") or "\\" in decoded or "\x00" in decoded:
        raise KnowledgeError("absolute or unsafe link destination")
    if parsed.query:
        raise KnowledgeError("local query links unsupported")
    if not parsed.path:
        return page  # Anchor existence is outside this structural subset.
    parts = list(PurePosixPath(page).parent.parts)
    for item in parsed.path.split("/"):
        if item in {"", "."}:
            continue
        if item == "..":
            if not parts:
                raise KnowledgeError("link escapes wiki snapshot")
            parts.pop()
        else:
            parts.append(item)
    return "/".join(parts)


def _markdown(files):
    diagnostics, index_links = [], set()
    for page in sorted(files):
        if not page.endswith(".md"):
            continue
        try:
            text = _without_code(files[page].decode("utf-8"))
        except UnicodeDecodeError:
            diagnostics.append(f"{page}: invalid UTF-8")
            continue
        if re.search(r"(?m)^\s*\[[^\]\n]+\]:", text):
            diagnostics.append(f"{page}: reference-style link definitions unsupported; use inline links")
        if re.search(r"<(?:a|img)\b[^>]*(?:href|src)\s*=", text, re.I):
            diagnostics.append(f"{page}: HTML links/images unsupported; use inline links")
        for match in re.finditer(r"!?\[[^\]\n]*\]\(([^)\n]*)\)", text):
            try:
                target = _local_target(page, _destination(match.group(1)))
                if target is not None:
                    if target not in files:
                        raise KnowledgeError(f"broken local link: {target}")
                    if page == "index.md":
                        index_links.add(target)
            except (ValueError, TypeError) as exc:
                diagnostics.append(f"{page}: {exc}")
    for page in sorted(files):
        if page.endswith(".md") and page.startswith(("topics/", "sources/")) and page not in index_links:
            diagnostics.append(f"index.md: missing page link: {page}")
    return diagnostics


def lint_knowledge(wiki_dir, manifest, source_bytes_by_id):
    """Return deterministic diagnostics; [] means only the documented checks passed."""
    try:
        files = _read_tree(wiki_dir)
        missing = [name for name in ("index.md", "claims.jsonl") if name not in files]
        if missing:
            return ["missing required wiki file: " + name for name in missing]
        sources = _sources(manifest, source_bytes_by_id)
        return _claims(files["claims.jsonl"], sources) + _markdown(files)
    except (OSError, ValueError, TypeError, RecursionError) as exc:
        return [f"knowledge input error: {exc}"]
