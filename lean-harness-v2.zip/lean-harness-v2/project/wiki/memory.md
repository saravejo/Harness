# Operational memory

## Active decisions

## Lessons

## Change history
