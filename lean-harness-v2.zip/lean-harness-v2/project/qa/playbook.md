# Evidence-bound review

Read: the registered task contract, its pinned source evidence, hard-check results
and captured candidate snapshot. Do not substitute the mutable working candidate.
Avoid generator history when it is unnecessary; a fresh context is a mitigation,
not proof of independent judgment. A source citation must be inspected for support.

For each required criterion, return pass, fail or unknown with evidence.
For an omission, cite the requirement ID and inspected scope; no quote of missing
text is possible or required. For a false statement, cite candidate and source.
All required criteria must pass. Missing, unknown or critical failures block release.
Preference scores cannot compensate for a failed requirement.

For optional pairwise comparisons, hide candidate identity and swap presentation
order. Inconsistent preference is unresolved/tie. A consistent preference is still
not evidence that either candidate meets the absolute acceptance criteria.

Reviewers must have enough authority and domain expertise for the task. The reviewer
name in JSON is a label, not authentication; the controlled submission channel is
the trust boundary. A separate tool-call context alone does not establish independence.

The reference runner validates receipt structure, required criterion coverage and
snapshot binding. It cannot validate the reasoning or honesty of the reviewer.
No persona count, two-round cap or five-minute threshold is a universal default.
