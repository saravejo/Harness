# Bounded autonomous experiments

Read this only for an iterative optimization task. The agent defines task-specific
experiments; `controller/experiment.py` runs the measured keep/discard loop. Do not
start an endless background process or require the user to complete a demo.

## Establish the experiment

1. Translate the user's actual objective into an observable metric, its direction,
   and non-negotiable validity checks. Reuse an applicable existing evaluator.
   A proxy metric needs a stated limitation; an LLM's unexplained preference score
   is not objective evidence. Ask only when materially different objectives cannot
   be resolved from context. For ordinary editing with no useful metric, finish the
   task and verify requirements instead of inventing optimization.
2. Freeze the evaluator, evaluation data, allowed editable files, seeds/repetitions,
   minimum meaningful change, and budget before measuring the baseline. Keep the
   evaluator/data outside the mutable candidate. For noisy measurements, decide
   aggregation/repetitions in the evaluator beforehand; do not cherry-pick a run.
   If a holdout is available, use it for final validation, not proposal selection.
3. Use the user's budget. Otherwise state a modest default of three proposals,
   60 seconds per command, and 300 seconds total, including baseline evaluation.
   These are configurable stopping limits, not claims about optimal search effort.
   Count failed proposals, invalid results, and crashes; do not retry indefinitely.
4. Have the agent create a minimal task-specific configuration only when needed,
   for example `results/candidates/<task>/experiment.json`. The baseline contains
   only relevant inputs/artifacts; copy existing user work, never reset its branch.
   Commands are argv arrays, not interpolated shell strings. The state directory
   must be new and disjoint from the baseline. Do not use a candidate as the working
   project, controller, trusted state, or evaluator directory.

The configuration has exactly these keys (paths are resolved relative to the
configuration file's parent; use actual paths and task-specific values):

```json
{
  "schema_version": 1,
  "goal": "The user's actual measurable objective and constraints",
  "baseline": "<baseline directory>",
  "mutable_files": ["<relative text artifact path>"],
  "proposer": ["<proposal program>", "<argument>"],
  "evaluator": ["<evaluation program>", "<argument>"],
  "evaluator_inputs": ["<actual evaluator/data file path>"],
  "direction": "min",
  "min_delta": 0,
  "max_experiments": 3,
  "command_timeout_seconds": 60,
  "total_timeout_seconds": 300
}
```

`direction` is `min` or `max`. `max_experiments` excludes the one baseline
evaluation. List all evaluator code/data files in `evaluator_inputs` so changed
listed inputs are detected; unlisted dependencies are not magically pinned.
`min_delta` is a nonnegative acceptance threshold, not a statistical significance
test. Do not modify the configuration or acceptance criterion after seeing results.

## Execute without repeated permission prompts

From `project/`, invoke the configured loop:

```bash
python3 -I ../controller/experiment.py run --config <actual-config.json> --state <new-run-directory>
```

The proposer receives JSON on stdin containing the goal, current best metric,
allowed file contents, iteration, and history. It must return exactly
`{"hypothesis":"A concrete expected improvement","files":{"allowed/path":"full new text"}}`.
It may change only listed files. The evaluator runs in a separate candidate
directory with `HARNESS_CANDIDATE` identifying it and returns exactly
`{"valid":true,"metric":1.0}`; invalid candidates return `valid:false` and may use
`metric:null`. Put correctness checks in the evaluator; metric alone is insufficient.
Logs and diagnostic text must not corrupt the evaluator's JSON stdout.

The engine measures the baseline, then repeats: propose one hypothesis, create a
candidate from the current best, evaluate, and keep only a valid improvement beyond
the configured threshold. Ties, regressions, invalid outputs, crashes, timeouts,
and unsafe proposals never become best. This deliberately rejects ties even when
a candidate is simpler; simplicity is not an unmeasured exception to the contract. Discard means the best pointer stays on
the previous snapshot; no destructive reset of the user's repository is needed.
It stops at the proposal or time budget. Inspect the actual summary and telemetry;
an interrupted run or absent measurement is not a success. Reused run directories
are rejected; inspect them before starting a new run, never erase failed evidence.

An external model/CLI proposer must be available for unattended generation. The
engine does not contain a model or provide API credentials. If using an active
Claude Code session without an external proposer, perform the same bounded loop
in-session: record the fixed contract/baseline, change only allowed candidate files,
execute the real evaluator after each proposal, log result/status, and retain only
the measured best. State that this was agent-orchestrated, not an engine run. Do
not claim unattended scheduling, engine-enforced budgets, or immutable telemetry
for this fallback.

With Claude Code already installed and authenticated, the bundled adapter can be
the proposer: `["python3", "/absolute/path/to/controller/claude_proposer.py"]`.
It makes one fresh print-mode call per proposal and requests JSON without tools.
Keep normal authentication and permission controls; no bypass flag is required.
Live provider integration was not tested in the supplied development environment.
The adapter's child process is subject to the engine's command timeout. Paths in
argv that name existing files are resolved relative to the config; use absolute
paths for tools/data and for arguments that name directories to avoid ambiguity.

## Finish and learn

- Revalidate the chosen snapshot against all task requirements and any held-out
  checks. Report baseline versus best, actual attempts, failed/unknown checks, the
  metric's limitations, and the stopping reason. A baseline can remain the winner.
- Deliver the exact chosen snapshot. If release control is configured, send that
  snapshot through its checks and evidence-bound review; experiment selection does
  not bypass acceptance or automatically publish anything externally.
- Save a concise reusable finding through `qa/wiki.md` only when supported by the
  experiment evidence. Record scope, configuration, and run references; retain
  uncertainty and failed hypotheses where they prevent repeated mistakes.
- Candidate execution and configured subprocesses use the caller's permissions.
  Copying directories and checking hashes are not OS isolation. Use an actual
  protected runtime for untrusted code or stronger tamper resistance.
