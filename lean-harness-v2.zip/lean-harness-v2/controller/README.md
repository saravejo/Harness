# Lean harness v2 controllers

The short project instructions route ordinary work, wiki work, and measurable
optimization without a demo or mandatory task registration. The complete wiki
and experiment routines are in `project/qa/wiki.md` and `project/qa/experiments.md`;
read only the workflow relevant to the task.

- `experiment.py` executes a bounded baseline/propose/evaluate/keep-discard loop.
  It requires a task-specific evaluator and a JSON proposer command. The optional
  `claude_proposer.py` adapter uses an installed, authenticated Claude Code CLI;
  a real provider call was not tested in this environment. No model or credentials
  are bundled. The agent can instead perform the documented loop in its current
  session, without claiming engine-enforced controls.
- `wiki_check.py` provides read-only structural preflight without registration.
  The LLM performs ingest, query, synthesis, and semantic maintenance according to
  the wiki workflow. A structural pass is not a semantic review.
- `runner.py` and `knowledge.py` retain the separate, optional release-control
  interface described below. An experiment winner is not an accepted release.

Python 3.10+ and POSIX are required. Run `python3 -I tests/run_tests.py` from the kit
root for the combined test suite. Candidate execution uses the caller's actual
permissions: subprocesses, copied directories, and hashes are not an OS sandbox.

## Release controller

The release controller implements snapshot-bound structural checks and recorded review
acceptance. It does not authenticate reviewers, enforce operating-system isolation,
judge semantic truth, run candidate code, or schedule model calls. Deploy the
controller and trusted state under a protected owner/service identity. The working
agent must not modify either or invoke administrative operations as that identity.

Use Python 3.10+ on compatible POSIX systems. `flock`, descriptor-relative opens
and `O_NOFOLLOW` are required. Install the complete `controller/` directory outside
the project. `runner.py` and `knowledge.py` are both pinned; knowledge validation
executes its pinned source bytes directly, ignoring cached bytecode. Protect the
Python runtime and dependencies separately. The hashes are not digital signatures.

## Commands

Run from a trusted shell/service. These paths are illustrative placeholders:

```bash
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state doctor --task task-001
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state register --task task-001
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state evaluate --task task-001 --candidate candidate-001 --run run-001
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state review --run run-001 --file /protected/review.json
python3 -I /protected/controller/runner.py --project /work/project --state /protected/state promote --run run-001 --release release-001
python3 -I /protected/controller/runner.py --state /protected/state verify-release --release release-001
```

Project, controller directory and trusted state must be disjoint directories.
`doctor` reads configuration and checks paths/schema without creating state. A
successful preflight does not prove sandbox or connector permissions are enforced.
`verify-release` requires no current project. The other operations require it.

## Strict task schema

Save a task at `tasks/<task_id>.json` with exactly these keys:

```json
{
  "schema_version": 2,
  "task_id": "task-001",
  "profile": "text-v2",
  "goal": "The complete semantic objective and required outcome.",
  "modules": ["sources", "knowledge"],
  "limits": {"max_evaluations": 3},
  "required_files": [
    {"path": "report.md", "headings": ["# Report"], "require_citations": true}
  ],
  "review_criteria": ["grounding", "completeness"]
}
```

The only module selections are `[]`, `["sources"]` and
`["sources", "knowledge"]`. Knowledge requires sources. Source-free tasks load no
manifest or wiki; `require_citations` must be false and citation markers are not
accepted. Unknown profiles, extra keys, duplicate identifiers and empty checks
are rejected. Required artifact paths are relative to
`results/candidates/<candidate-id>/artifacts/`. The exact file set must match.

The profile checks nonempty UTF-8 files, literal heading lines and `[[S1:L1-L2]]`
source references with inclusive, one-based text line numbers. When sources are
enabled, `raw/manifest.json` has exactly this structure:

```json
{"sources":[{"id":"S1","path":"sources/example.txt","sha256":"<actual SHA-256>"}]}
```

All raw files except the manifest must be listed, including hidden files. Paths
are relative to raw. Citation syntax and valid locators do not prove that a source
supports a claim, that every claim is cited, or that the output is complete.

Knowledge mode snapshots `wiki/` before calling `knowledge.py`. It checks required
`index.md`/`claims.jsonl`, structured claim references, supersession and the
documented subset of Markdown links. See `knowledge.py` for the exact format and
limits. Source summaries are optional. Unrelated wiki defects cannot block a task
whose knowledge module is disabled.

## Evaluation limits and evidence

Registration pins task bytes, source manifest/content when enabled, the rubric
at `qa/playbook.md`, and both controller source files. Relevant input changes
require a new task ID/version and registration. Captured run inputs contain the
task, rubric, controller files and optional raw/wiki snapshots.

The controller serializes admissions using its trusted-state lock. An accepted
evaluation writes `admission.json` before copying/evaluating. The cap counts all
admitted evaluations, including failures, errors and interrupted runs that have
no receipt. Missing candidates, stale registration, reused IDs and other preflight
failures do not consume a new admission. Corrupt or incomplete admission history
blocks further work until trusted recovery; the controller never guesses a lower
count. This caps evaluations only, not model generations, time, tokens or money.

Run IDs and release IDs are never reused. A completed evaluation retains a
`pass`, `fail` or `error` receipt. Interrupted work remains visible through its
admission. No absent, failed or unknown check is treated as passing.

## Review

The trusted reviewer must inspect the captured candidate, complete contract,
rubric and relevant frozen sources/wiki. Supply exactly:

```json
{
  "run_id":"run-001",
  "candidate_sha256":"<receipt value>",
  "contract_sha256":"<receipt value>",
  "reviewer":"<reviewer identity or service>",
  "criteria":[
    {"id":"grounding","status":"pass","evidence":"<actual inspected locations>"},
    {"id":"completeness","status":"pass","evidence":"<actual contract comparison>"}
  ]
}
```

Every required criterion occurs exactly once; statuses are `pass`, `fail` or
`unknown`. Only all-pass qualifies. Evidence must be nonempty but its truth is
not checked by this controller. Reviewer identity is metadata, not authenticated
identity. Do not submit a working-agent self-report as authoritative review.

## Promotion and historical verification

Promotion checks current pins plus frozen run integrity, copies evaluated bytes
into a staging directory and atomically renames that directory on the same
filesystem. A separately protected publication record binds the release tree and
historical registration/receipt/review/admission. A crash between publication
record creation and rename leaves an incomplete publication that cannot verify.
There is no crash-durability or cross-filesystem atomicity guarantee.

`verify-release` checks the frozen artifact/input bytes, historical acceptance,
controller/rubric/contract/source/wiki binding and protected history. It succeeds
after legitimate current-project changes or project removal. It detects covered
release/history tampering but does not prove current suitability, semantic truth,
reviewer authenticity, or safety against someone who controls all trusted records.
Keep the protected historical state; do not delete it as candidate cleanup.

The authoritative release is `STATE/releases/<release-id>/`; the template has no
second mutable final directory. Publishing externally is a separate operation.

## Resource bounds and tests

Each intake allows 10 MiB/file, 50 MiB/tree, 1000 files, 5000 directory entries and
64 nested subdirectories. These are bounded-reference limits, not tuned optima.
Symlinks, unsafe paths and nonregular files are rejected. Directory descriptors
prevent the reproduced ancestor-symlink read race.

Run `python3 -I tests/run_tests.py` from the kit root. Tests exercise structural,
snapshot, limit, review, module and historical-verification behavior. They do not
benchmark LLM quality or establish actual deployment isolation.
